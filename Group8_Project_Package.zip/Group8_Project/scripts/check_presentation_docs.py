"""Verify the authored handouts and their final Word and Poppler QA renders."""
import hashlib
import json
import re
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn
from PIL import Image, ImageChops
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
checks = []
for stem, folder, pages, pictures in [
    ("Group8_PPT_Content_Pack", "content_final", 12, 4),
    ("Group8_Presentation_Review_and_QA", "review_final", 9, 2),
]:
    path = ROOT / "output" / "docx" / (stem + ".docx")
    doc = Document(path)
    render = ROOT / "tmp" / "docx_qa" / folder
    pdf = PdfReader(render / (stem + ".pdf"))
    assert len(pdf.pages) == pages
    page_text = [page.extract_text() for page in pdf.pages]
    assert all(len(text.split()) > 15 for text in page_text), "Blank page"
    text = "\n".join(page_text)
    assert all(value in text for value in ["88.75%", "0.8315", "64.42%"])
    assert len(doc.inline_shapes) == pictures
    assert any(p.style.name == "Title" for p in doc.paragraphs)
    for section in doc.sections:
        assert abs(section.page_width.inches - 8.5) < .01
        assert abs(section.page_height.inches - 11) < .01
    for name in ["Title", "Heading 1", "Heading 2"]:
        assert str(doc.styles[name].font.color.rgb) == "000000"
    for shape in doc.inline_shapes:
        assert shape._inline.docPr.get("descr"), "Image lacks alt text"
    for table in doc.tables:
        assert table._tbl.tblPr.find(qn("w:tblBorders")) is not None
        assert table.rows[0]._tr.trPr.find(qn("w:tblHeader")) is not None
    pngs = list(render.glob("page-*.png"))
    assert len(pngs) == pages
    for png in pngs:
        red, green, blue = Image.open(png).convert("RGB").split()
        assert ImageChops.difference(red, green).getbbox() is None
        assert ImageChops.difference(red, blue).getbbox() is None
    if pages == 12:
        assert all(f"Slide {i} " in page_text[i-1] for i in range(1, 13))
        assert len(doc.tables[2].rows) == 10
    else:
        questions = [int(n) for p in doc.paragraphs for n in re.findall(r"^Q(\d+)\b", p.text)]
        assert questions == list(range(1, 42))
        assert len(doc.tables[4].rows) == 11
        for value in ["464,809", "58,101", "58,102", "16,307", "5,657", "91.24", "73.10", "4,649", "0.0002"]:
            assert value in text, value
    checks.append({"file": str(path.relative_to(ROOT)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                   "pages": pages, "embedded_images": pictures, "editable_tables": len(doc.tables)})

assert hashlib.sha256((ROOT / "Group8_Notebook.ipynb").read_bytes()).hexdigest() == "ff2b2b4bb259a01e142f7a77ebe433e0f1e2059cf1c15d4347f826ab3464a128"
assert hashlib.sha256((ROOT / "output/pdf/Group8_Report.pdf").read_bytes()).hexdigest() == "76d8b75636d22ff2b1dc6fc86c2fa43eba476578424bb0e1d2afa609fbedca49"
result = {"outputs": checks, "render_engine": "Native Microsoft Word PDF export and bundled Poppler page renders",
          "visual_review": "All 21 final page images inspected", "planned_slides": 12,
          "talk_seconds": 600, "practice_questions": 41, "new_model_or_test_calls": 0,
          "accessibility": "Image alt text and table headers checked; full accessibility certification not performed"}
(ROOT / "artifacts/presentation_docs_verification.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
