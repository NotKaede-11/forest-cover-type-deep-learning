"""Author two Word handouts from the completed study, using bundled dependencies."""
import ast
import csv
import json
import re
import subprocess
from html.parser import HTMLParser
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / "artifacts"
OUT = ROOT / "output" / "docx"
ASSETS = ROOT / "figures" / "presentation"
TEMP = ROOT / "tmp" / "presentation_assets"
for directory in [OUT, ASSETS, TEMP]:
    directory.mkdir(parents=True, exist_ok=True)
POPPLER = Path(r"C:\Users\Beo\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe")

def load(name):
    return json.loads((ART / name).read_text(encoding="utf-8"))

def rows(name):
    with (ART / name).open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))

final = load("final_test_metrics.json")
selection = load("selection.json")
summary = load("analysis_summary.json")
runs = rows("Group8_Experiment_Log.csv")
classes = rows("Group8_Per_Class_Test_Metrics.csv")
split_metrics = rows("Group8_Split_Metrics.csv")
errors = rows("Group8_Five_Errors.csv")
assert selection["run_id"] == "R1" and final["evaluate_calls"] == 1
assert len(runs) == 9 and len(classes) == 7 and len(errors) == 5
pct = lambda value: f"{float(value)*100:.2f}%"
four = lambda value: f"{float(value):.4f}"

# Reuse the report's verified APA 7 source metadata, without importing its builder.
tree = ast.parse((ROOT / "scripts" / "make_report.py").read_text(encoding="utf-8"))
references = next(ast.literal_eval(node.value) for node in tree.body
                  if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "refs" for t in node.targets))

def png_from_pdf(pdf, stem):
    subprocess.run([str(POPPLER), "-singlefile", "-r", "180", "-png", str(pdf), str(ASSETS / stem)], check=True, capture_output=True)
    return ASSETS / (stem + ".png")

def build_visuals():
    path = TEMP / "network.pdf"
    c = canvas.Canvas(str(path), pagesize=(620, 238))
    c.setFont("Helvetica-Bold", 16)
    c.drawCentredString(310, 215, "Baseline and wider candidate")
    for y, label, units, count in [(144, "R0 Baseline", 50, 5657), (49, "R1 Wider", 100, 16307)]:
        c.setFont("Helvetica-Bold", 11)
        c.drawString(8, y + 21, label)
        blocks = [("54", "Inputs"), (str(units), "ReLU"), (str(units), "ReLU"), ("7", "Softmax")]
        for j, (number, kind) in enumerate(blocks):
            x = 96 + j*132
            c.setFillGray(.94)
            c.setStrokeGray(.25)
            c.rect(x, y, 93, 45, fill=1, stroke=1)
            c.setFillGray(0)
            c.setFont("Helvetica-Bold", 15)
            c.drawCentredString(x + 46.5, y + 26, number)
            c.setFont("Helvetica", 11)
            c.drawCentredString(x + 46.5, y + 9, kind)
            if j < 3:
                c.line(x + 97, y + 22, x + 127, y + 22)
                arrow = c.beginPath()
                arrow.moveTo(x + 127, y + 22)
                arrow.lineTo(x + 121, y + 25)
                arrow.lineTo(x + 121, y + 19)
                arrow.close()
                c.drawPath(arrow, fill=1, stroke=0)
        c.setFont("Helvetica", 11)
        c.drawCentredString(357, y - 17, f"{count:,} trainable parameters")
    c.save()
    model_png = png_from_pdf(path, "Group8_Network_Architecture")

    path = TEMP / "recall.pdf"
    c = canvas.Canvas(str(path), pagesize=(620, 405))
    c.setFont("Helvetica-Bold", 16)
    c.drawCentredString(310, 380, "Test recall by true class")
    matrix = rows("Group8_Confusion_Normalized.csv")
    names = [row["cover_type"] for row in classes]
    short = ["Spruce/Fir", "Lodgepole", "Ponderosa", "Cotton/W", "Aspen", "Douglas", "Krummholz"]
    left, bottom, size = 218, 83, 37
    for i, row in enumerate(matrix):
        for j, name in enumerate(names):
            value = float(row[name])
            c.setFillGray(1 - value*.95)
            x, y = left + j*size, bottom + (6-i)*size
            c.rect(x, y, size, size, fill=1, stroke=0)
            c.setFillGray(1 if value > .5 else 0)
            c.setFont("Helvetica", 12)
            c.drawCentredString(x + size/2, y + size/2 - 4, f"{value:.2f}")
    c.setFillGray(0)
    c.setFont("Helvetica", 11)
    for i, name in enumerate(names):
        c.drawRightString(left - 7, bottom + (6-i)*size + size/2 - 4, name)
    for j, name in enumerate(short):
        c.saveState()
        c.translate(left + j*size + size/2, bottom - 7)
        c.rotate(45)
        c.drawRightString(0, 0, name)
        c.restoreState()
    c.drawCentredString(left + 3.5*size, 12, "Predicted class")
    c.save()
    return model_png, png_from_pdf(path, "Group8_Test_Recall")

def set_font(style, size, name="Calibri", bold=False):
    style.font.name = name
    style.font.size = Pt(size)
    style.font.bold = bold
    style.font.color.rgb = RGBColor(0, 0, 0)
    rpr = style.element.get_or_add_rPr()
    fonts = rpr.find(qn("w:rFonts"))
    if fonts is not None:
        for key in ["asciiTheme", "hAnsiTheme", "eastAsiaTheme", "cstheme"]:
            fonts.attrib.pop(qn("w:" + key), None)
        fonts.set(qn("w:ascii"), name)
        fonts.set(qn("w:hAnsi"), name)
    color = rpr.find(qn("w:color"))
    if color is not None:
        for key in ["themeColor", "themeTint", "themeShade"]:
            color.attrib.pop(qn("w:" + key), None)

def setup(title, purpose):
    doc = Document()
    section = doc.sections[0]
    section.page_width, section.page_height = Inches(8.5), Inches(11)
    section.top_margin = section.bottom_margin = Inches(.6)
    section.left_margin = section.right_margin = Inches(.7)
    section.header_distance = section.footer_distance = Inches(.25)
    set_font(doc.styles["Normal"], 11)
    doc.styles["Normal"].paragraph_format.line_spacing = 1.05
    doc.styles["Normal"].paragraph_format.space_after = Pt(5)
    for name, size in [("Title", 22), ("Heading 1", 16), ("Heading 2", 12)]:
        set_font(doc.styles[name], size, bold=True)
        doc.styles[name].paragraph_format.space_before = Pt(8 if name != "Title" else 0)
        doc.styles[name].paragraph_format.space_after = Pt(6)
        doc.styles[name].paragraph_format.keep_with_next = True
        ppr = doc.styles[name].element.get_or_add_pPr()
        for border in list(ppr.findall(qn("w:pBdr"))):
            ppr.remove(border)
    for name in ["List Bullet", "List Number", "Caption"]:
        set_font(doc.styles[name], 11 if name != "Caption" else 9)
    if "APA Reference" not in doc.styles:
        doc.styles.add_style("APA Reference", 1)
    reference = doc.styles["APA Reference"]
    set_font(reference, 12, "Times New Roman")
    reference.paragraph_format.line_spacing = 2
    reference.paragraph_format.left_indent = Inches(.5)
    reference.paragraph_format.first_line_indent = Inches(-.5)
    reference.paragraph_format.space_after = Pt(0)
    doc.core_properties.title = title
    doc.core_properties.author = "Group 8"
    doc.core_properties.subject = purpose
    doc.core_properties.keywords = "Forest Cover Type, Group 8, presentation preparation"
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = footer.add_run("Group 8   ")
    run.font.size = Pt(9)
    run.font.color.rgb = RGBColor(80, 80, 80)
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    footer._p.append(field)
    return doc

def para(doc, text, bold=False, style=None):
    p = doc.add_paragraph(style=style)
    p.add_run(text).bold = bold
    return p

def bullets(doc, texts):
    for text in texts:
        para(doc, text, style="List Bullet")

def image(doc, path, width, alt):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(4)
    shape = p.add_run().add_picture(str(path), width=Inches(width))
    shape._inline.docPr.set("descr", alt)
    return p

def table(doc, headers, records, widths, font_size=10.5):
    t = doc.add_table(rows=1, cols=len(headers))
    t.autofit = False
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for column, width in zip(t.columns, widths):
        column.width = Inches(width)
    for i, text in enumerate(headers):
        t.rows[0].cells[i].text = str(text)
    for record in records:
        cells = t.add_row().cells
        for cell, text in zip(cells, record):
            cell.text = str(text)
    repeat = OxmlElement("w:tblHeader")
    t.rows[0]._tr.get_or_add_trPr().append(repeat)
    borders = OxmlElement("w:tblBorders")
    for side in ["top", "left", "bottom", "right", "insideH", "insideV"]:
        b = OxmlElement("w:" + side)
        for key, value in [("val", "single"), ("sz", "4"), ("color", "D9D9D9")]:
            b.set(qn("w:" + key), value)
        borders.append(b)
    t._tbl.tblPr.append(borders)
    for row_index, row in enumerate(t.rows):
        cant_split = OxmlElement("w:cantSplit")
        row._tr.get_or_add_trPr().append(cant_split)
        for j, (cell, width) in enumerate(zip(row.cells, widths)):
            cell.width = Inches(width)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcpr = cell._tc.get_or_add_tcPr()
            margins = OxmlElement("w:tcMar")
            for side, value in [("top", "60"), ("bottom", "60"), ("left", "75"), ("right", "75")]:
                m = OxmlElement("w:" + side)
                m.set(qn("w:w"), value)
                m.set(qn("w:type"), "dxa")
                margins.append(m)
            tcpr.append(margins)
            if row_index == 0:
                shading = OxmlElement("w:shd")
                shading.set(qn("w:fill"), "EEEEEE")
                tcpr.append(shading)
            for p in cell.paragraphs:
                p.paragraph_format.space_after = Pt(0)
                p.paragraph_format.line_spacing = 1.02
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT if j in [0,1] else WD_ALIGN_PARAGRAPH.CENTER
                for run in p.runs:
                    run.font.name = "Calibri"
                    run.font.size = Pt(font_size)
                    run.font.color.rgb = RGBColor(0,0,0)
                    run.bold = row_index == 0
    doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return t

class ReferenceParser(HTMLParser):
    def __init__(self, paragraph):
        super().__init__()
        self.p, self.italic = paragraph, False
    def handle_starttag(self, tag, attrs):
        if tag == "i": self.italic = True
    def handle_endtag(self, tag):
        if tag == "i": self.italic = False
    def handle_data(self, data):
        self.p.add_run(data).italic = self.italic

def add_references(doc):
    for label, url in references:
        p = doc.add_paragraph(style="APA Reference")
        ReferenceParser(p).feed(label + " " + url)

SLIDES = [
    ("Forest cover classification", 30, "Data Lead"),
    ("The Forest Cover Type data", 45, "Data Lead"),
    ("Two classes dominate the data", 45, "Data Lead"),
    ("Keep training validation and test separate", 45, "Data Lead"),
    ("Start with the taught baseline", 60, "Model Lead"),
    ("Compare one change at a time", 75, "Model Lead"),
    ("Select using validation macro F1", 60, "Experiment Lead"),
    ("Evaluate the frozen model once", 60, "Experiment Lead"),
    ("Check performance for each class", 60, "Experiment Lead"),
    ("Examine five wrong predictions", 60, "Report Lead"),
    ("Use the model with limits", 45, "Report Lead"),
    ("References", 15, "Report Lead"),
]
assert sum(seconds for _, seconds, _ in SLIDES) == 600

def slide_start(doc, number, first=False):
    title, seconds, role = SLIDES[number-1]
    heading = doc.add_heading(f"Slide {number} {title}", level=1)
    heading.paragraph_format.page_break_before = not first
    p = para(doc, f"{role}   |   {seconds} seconds", style="Caption")
    p.paragraph_format.space_after = Pt(10)

def make_content(model_png, recall_png):
    doc = setup("Forest Cover Type slide content", "Short copy and visuals for a twelve slide group presentation")
    doc.add_paragraph("Forest Cover Type slide content", style="Title")
    para(doc, "Copy the slide text, tables and visuals into your own deck. The 12 slides total 10 minutes. Use the separate review guide for explanations and Q&A.")
    slide_start(doc, 1, True)
    bullets(doc, ["Predict one of seven forest cover types", "Dense neural networks on land attributes", "Group 8"])
    para(doc, "Add your actual member names on this opening slide.", style="Caption")
    slide_start(doc, 2)
    bullets(doc, ["581,012 land cells in Colorado", "54 inputs and seven cover classes", "Each row represents a 30 x 30 metre cell"])
    table(doc, ["Input group", "Columns"], [["Terrain distances and hillshade",10],["Wilderness indicators",4],["Soil indicators",40]], [5.1, 1.9])
    para(doc, "Source: Blackard (1998, 1999).", style="Caption")
    slide_start(doc, 3)
    bullets(doc, ["Two dominant classes hold 85.22% of rows", "Cottonwood/Willow holds 0.47%", "Overall accuracy can hide class failures"])
    image(doc, ROOT / "figures" / "Group8_Class_Counts.png", 7.0, "Class counts showing Lodgepole Pine and Spruce Fir dominate the full dataset")
    para(doc, "Source: loaded dataset; Blackard (1998).", style="Caption")
    slide_start(doc, 4)
    table(doc, ["Training", "Validation", "Test"], [["464,809 rows", "58,101 rows", "58,102 rows"],["Fit the model", "Choose settings", "Final assessment"]], [2.35,2.35,2.3])
    bullets(doc, ["Stratified split with fixed seeds", "Fit scaling on training rows only", "Scale 10 numeric columns and preserve 44 binary columns"])
    para(doc, "Sources: saved split indices; scikit-learn developers (n.d.-b).", style="Caption")
    slide_start(doc, 5)
    bullets(doc, ["Baseline has two 50 unit ReLU layers", "Adam and sparse categorical cross entropy", "Early stopping with patience 2"])
    image(doc, model_png, 7.0, "R0 has 54 50 50 7 units while wider candidate R1 has 54 100 100 7 units")
    para(doc, "Sources: saved model configurations; Keras (n.d.-b, n.d.-c).", style="Caption")
    slide_start(doc, 6)
    short_changes = ["Baseline", "Width 100 100", "Depth 50 50 50", "tanh", "Batch 500", "LR 0.0003", "Patience 5", "Class weights", "Dropout 0.2"]
    table(doc, ["Run", "Change", "Epochs", "Val loss", "Val acc", "Macro F1"],
          [[r["run_id"], label, r["epochs_run"], four(r["val_loss"]), pct(r["val_accuracy"]), four(r["val_macro_f1"])] for r,label in zip(runs,short_changes)],
          [.48,2.0,.65,1.0,.95,1.0], font_size=10.5)
    bullets(doc, ["Each variant compares with R0", "Same data split seed policy and epoch cap"])
    para(doc, "Epochs are completed epochs. Validation scores use restored weights.", style="Caption")
    slide_start(doc, 7)
    bullets(doc, ["R1 selected by validation macro F1 of 0.8272", "13 epochs run and epoch 11 restored", "R1 and R6 differ by only 0.0002 macro F1"])
    image(doc, ROOT / "figures" / "Group8_Best_Loss_Curve.png", 7.0, "R1 training and validation loss with restored epoch 11 marked")
    slide_start(doc, 8)
    table(doc, ["Partition", "Accuracy"], [[r["split"].capitalize(),pct(r["accuracy"])] for r in split_metrics], [4.7,2.3])
    bullets(doc, ["Test accuracy 88.75%", "Test macro F1 0.8315", "One final test evaluation"])
    slide_start(doc, 9)
    bullets(doc, ["Balanced accuracy 83.24%", "Douglas-fir recall 64.42%", "Cottonwood/Willow recall 91.24% on 274 test cells"])
    image(doc, recall_png, 6.5, "Normalized test confusion matrix with Douglas fir recall 0.64 and Cottonwood Willow recall 0.91")
    para(doc, "Rows are true classes. Columns are predictions. The diagonal shows class recall.", style="Caption")
    slide_start(doc, 10)
    table(doc, ["Row", "True class", "Predicted class"], [[r["row_id"],r["true_class"],r["predicted_class"]] for r in errors], [.7,3.15,3.15])
    bullets(doc, ["Shared land conditions may blur class boundaries", "Unequal class representation may contribute", "These explanations are hypotheses"])
    slide_start(doc, 11)
    bullets(doc, ["Screening aid with human verification", "New region performance remains untested", "Validate locally before operational use"])
    para(doc, "The study covers Colorado data. It does not establish performance in Philippine forests.", style="Caption")
    slide_start(doc, 12)
    add_references(doc)
    path = OUT / "Group8_PPT_Content_Pack.docx"
    doc.save(path)
    return path

question_count = 0
def qa(doc, question, answer):
    global question_count
    question_count += 1
    p = doc.add_paragraph()
    p.paragraph_format.keep_with_next = True
    p.paragraph_format.space_after = Pt(2)
    p.add_run(f"Q{question_count}  {question}").bold = True
    para(doc, answer)

def review_page(doc, title):
    heading = doc.add_heading(title, level=1)
    heading.paragraph_format.page_break_before = True

def make_review(model_png, recall_png):
    doc = setup("Forest Cover Type presentation review", "Study pointers likely questions and rehearsal for Group 8")
    doc.add_paragraph("Forest Cover Type presentation review", style="Title")
    para(doc, "Use this guide to explain the project without reading a script. Practise answering the numbered questions aloud, then ask another member to follow up. The selected model scored 88.75% test accuracy, but class recall and scope limits matter too.")
    doc.add_heading("Facts each member should know", level=1)
    table(doc, ["Item", "Answer"], [
        ["Task", "Predict one of seven forest cover types from tabular land attributes"],
        ["Dataset", "581,012 cells from four Colorado wilderness areas"],
        ["Inputs", "10 numeric measures and 44 binary indicators"],
        ["Split", "464,809 train   58,101 validation   58,102 test"],
        ["Baseline R0", "54 inputs  50 ReLU  50 ReLU  7 softmax"],
        ["Selected R1", "54 inputs  100 ReLU  100 ReLU  7 softmax"],
        ["Selection", "Highest validation macro F1 at the restored checkpoint"],
        ["Final test", "Accuracy 88.75%   macro F1 0.8315   balanced accuracy 83.24%"],
        ["Main weakness", "Douglas fir recall 64.42%"],
        ["Evaluation discipline", "One final evaluate call after validation selected R1"]], [1.5,5.5])
    doc.add_heading("A short opening you can adapt", level=2)
    para(doc, "Our project predicts forest cover from land attributes. We compared nine dense network configurations on the full dataset. We selected R1 using validation macro F1 and evaluated the frozen model once on the test set. It reached 88.75% accuracy, but Douglas fir recall was 64.42%, so we would use it with human verification and further validation for new regions.")
    doc.add_heading("Keep these distinctions clear", level=2)
    bullets(doc, ["Validation accuracy is not test accuracy.", "A small training validation gap does not prove new region reliability.", "High recall does not guarantee high precision.", "The five errors are selected examples with hypotheses about their causes."])
    para(doc, "Data source: Blackard (1998). Detailed source entries are on the final page.", style="Caption")

    review_page(doc, "Understand the data and preprocessing")
    qa(doc, "What does one row represent?", "One 30 x 30 metre land cell. Its 54 inputs describe terrain, distances, hillshade, wilderness area and soil. Its target is one cover type. The source is northern Colorado, not Philippine forests (Blackard, 1998, 1999).")
    qa(doc, "Why are there 54 columns but only ten to scale?", "Ten columns contain numeric measurements. Four wilderness and forty soil columns already encode membership as 0 or 1. We preserve those 44 binary columns.")
    qa(doc, "What did we check before training?", "Shape, seven labels, missing or nonfinite values, binary values, one active wilderness and soil indicator per row, disjoint split IDs, and feature hashes. The checks found no missing or nonfinite values and no repeated feature hashes across splits.")
    qa(doc, "Why subtract one from the target?", "Original labels 1 to 7 become model indices 0 to 6. Those indices correspond to the seven softmax positions. We keep the class name map for reporting.")
    qa(doc, "Why use a stratified split?", "It preserves class proportions while dividing rows. We hold out 20% with seed 42, then split that reserve equally into validation and test with seed 43. Integer rounding gives the recorded sizes.")
    qa(doc, "What is data leakage in this project?", "An example is fitting the scaler on all rows before splitting. That lets held out information affect preprocessing. We learn means and standard deviations from training rows only, then reuse them for the other partitions (scikit-learn developers, n.d.-b).")
    qa(doc, "How did we handle the imbalance?", "We kept all training rows and tested balanced training weights in R7. Validation and test kept their natural distribution. Downsampling every full dataset class to 2,747 rows would discard 96.69% of the data; we did not do that.")
    qa(doc, "Do disjoint rows prove there is no geographic leakage?", "No. They establish row separation, and hash checks found no identical input vectors across partitions. Nearby or related cells may still share conditions. We did not run an unseen area or spatial dependence study.")

    review_page(doc, "Explain the network and training")
    image(doc, model_png, 6.6, "Baseline and wider candidate network architecture")
    qa(doc, "Why use a dense network rather than a CNN?", "The inputs are tabular measurements, not image pixels. The assignment asks for dense networks. We did not compare this model with a CNN or claim it is the best possible method.")
    qa(doc, "What do ReLU and softmax do?", "ReLU applies a nonlinearity in the hidden layers, setting negative activations to zero. Softmax turns the seven output scores into values that sum to one. The largest output determines the predicted class.")
    qa(doc, "Why sparse categorical cross entropy?", "We have one integer class index per row and seven output probabilities. Sparse cross entropy matches that format. We use probabilities, so from_logits is False; the binary input columns do not require one hot targets.")
    qa(doc, "What does Adam or the learning rate change?", "Adam updates weights using gradient information with adaptive adjustments. The base learning rate controls the optimization step size. Our baseline uses 0.001; R5 changes that factor alone to 0.0003.")
    qa(doc, "What are an epoch and a batch?", "An epoch is one pass through the training rows. A batch is the group used for one gradient update. With 464,809 rows and batch 100 there are 4,649 batches, including the last partial batch.")
    qa(doc, "What does early stopping with patience two mean?", "Stop after two consecutive epochs without improved validation loss, subject to the epoch cap. We set restore_best_weights to True. R1 ran 13 epochs and restored epoch 11; patience is not a two epoch training limit (Keras, n.d.-b).")
    qa(doc, "How many parameters does R1 have?", "The first dense layer has 5,500 weights and biases, the second has 10,100, and the output has 707. Total 16,307. R0 has 5,657. Biases count as trainable parameters.")
    qa(doc, "Why can training and validation loss look different?", "Training uses batches while weights change. Dropout acts during training, and class weights change the loss objective in R7. Compare the same frozen model with matching inference metrics before claiming overfitting (Keras, n.d.-c).")

    review_page(doc, "Explain the controlled experiments")
    table(doc, ["Run", "Changed factor", "Epochs", "Val acc", "Macro F1"],
          [[r["run_id"],r["description"],r["epochs_run"],pct(r["val_accuracy"]),four(r["val_macro_f1"])] for r in runs],
          [.5,3.0,.7,1.3,1.5], font_size=10)
    qa(doc, "What makes these controlled comparisons?", "Each variant changes one factor from R0. Data, split, scaling, seed policy and epoch cap stay fixed. Each model starts with fresh weights, optimizer and callbacks; R2 is not a continuation of R1.")
    qa(doc, "Why did R1 win when R3 had higher accuracy?", "We declared validation macro F1 as the primary metric before training because each class matters. R1 has 0.8272 macro F1; R3 has 0.8254 despite 89.31% accuracy. We did not change that rule after looking at test results.")
    qa(doc, "Is R1 clearly better than R6?", "R1 leads by about 0.0002 validation macro F1. That is a small difference from one seed and one split. The rule selects R1, but these runs do not establish a reliable or universal advantage over R6.")
    qa(doc, "Why monitor loss but choose using macro F1?", "Early stopping chooses the checkpoint within each run using validation loss. We then compute macro F1 from that restored model to rank the runs. The logged loss, accuracy and macro F1 refer to the same weights.")
    qa(doc, "Did class weighting help?", "Each weight is training rows divided by seven times that class's training count. R7 raised mean class recall from 75.15% to 87.35%, but lowered accuracy from 85.75% to 79.59% and macro F1 from 0.7827 to 0.7353. It helped recall under a precision and accuracy trade off, not our primary objective.")
    qa(doc, "Did dropout help and why report it?", "R8 adds dropout 0.2 after each hidden layer. It masks activations during training and is disabled at inference (Keras, n.d.-a). Validation macro F1 fell by 0.0713 versus R0. We report that result; bonus eligibility depends on class coverage.")

    review_page(doc, "Read the final results and metrics")
    table(doc, ["Class", "Support", "Precision", "Recall", "F1"],
          [[r["cover_type"],f"{int(float(r['support'])):,}",pct(r["precision"]),pct(r["recall"]),four(r["f1-score"])] for r in classes],
          [2.4,.9,1.2,1.2,1.3], font_size=10)
    image(doc, recall_png, 5.2, "Test class recall confusion matrix with true classes as rows")
    qa(doc, "What are accuracy precision and recall?", "Accuracy is correct predictions divided by all rows. Precision asks how many predictions of a class are correct. Recall asks how many true members of that class we found. Here per class accuracy means recall.")
    qa(doc, "How do macro F1 and balanced accuracy differ?", "Macro F1 averages seven class F1 scores, each combining precision and recall. Balanced accuracy averages seven recalls. Our test values are 0.8315 macro F1 and 83.24% balanced accuracy (scikit-learn developers, n.d.-a).")
    qa(doc, "Which class needs the most attention?", "Douglas fir recall is lowest at 64.42%: 1,119 of 1,737 true cells were correct. Rarity alone does not determine the weakest class; the smallest class, Cottonwood Willow, reached 91.24% recall on 274 cells.")
    qa(doc, "Does high recall guarantee reliable positive predictions?", "No. Cottonwood Willow recall is 91.24%, but its precision is 73.10%. We recovered most true members while also assigning that label to some other cells. Support is small, so keep the class count visible.")
    qa(doc, "Is the selected model overfitting?", "Frozen model accuracy is 89.29% on train, 88.66% on validation and 88.75% on test. The train validation gap is 0.64 percentage points and the curves are close. That shows no large gap on this split, not proof of new region reliability.")

    review_page(doc, "Discuss mistakes and the client answer")
    table(doc, ["Row", "True", "Predicted", "Max score"],
          [[r["row_id"],r["true_class"],r["predicted_class"],pct(r["maximum_softmax"])] for r in errors],
          [.6,2.6,2.6,1.2], font_size=10)
    para(doc, "Rows 115 and 444 reverse Spruce Fir and Lodgepole Pine labels. Both have Rawah and soil indicator 29, so those two categorical features alone cannot separate the pair. Row 2844 confuses Ponderosa Pine with Douglas fir in Cache la Poudre, where both cover types occur (Blackard, 1999).")
    para(doc, "Row 2180 predicts Ponderosa Pine for Cottonwood Willow. The corresponding training counts are 28,603 and 2,198. Row 45 predicts the much more common Lodgepole Pine for Aspen. Unequal representation and shared land conditions are possible contributors; we did not establish the cause of any individual error.")
    qa(doc, "How were the five mistakes chosen?", "The lowest row ID error from each available true class until five cases, with remaining places filled by row ID. These are reproducible examples, not a random or representative sample of all 6,534 errors.")
    qa(doc, "Can we explain which feature caused a mistake?", "We can describe the recorded values and offer hypotheses. We did not compute local feature attributions or inspect the cells in the field. Do not say the network used a feature as the cause merely because that value appears unusual.")
    qa(doc, "Would we trust the model for a real client?", "As a screening aid for source like records with human verification. The score and class failures do not justify automatic operational forest management decisions. A new client region needs its own validation and a review of class error costs.")
    qa(doc, "Can it identify Philippine trees or forecast fires?", "This study provides no evidence for Philippine forests. It predicts one cover category from land attributes. It does not identify every tree, detect deforestation or forecast fires; distance to fire points is an input, not a fire risk output.")
    doc.add_heading("A defensible closing", level=2)
    para(doc, "The network performs well on held out source data, with uneven class recall. We would keep human verification and validate new areas before operational use. Our next research step is a new validation plan, including additional seeds and unseen areas, without using this test set to tune the model.")

    review_page(doc, "Know the notebook and live cell behavior")
    mapping = [
        ["1 / 2", "Setup", "Versions seeds helpers and CPU settings"],
        ["2 / 4", "Data checks", "Load data map labels class counts and hash checks"],
        ["3 / 5", "Dictionary", "All feature meanings and the class count plot"],
        ["4 / 7", "Preprocessing", "Split scale weights and frozen study manifest"],
        ["5 / 9", "Baseline", "Define dataset model callbacks and train R0"],
        ["6 / 11", "Experiments", "Train or load R1 to R8 rank and plot"],
        ["7 / 13", "Final phase", "Freeze winner evaluate once or load saved results"],
        ["8 / 15", "Metrics", "Split comparison class report and confusion matrix"],
        ["9 / 17", "Errors", "Select five mistakes and summarize limits"],
        ["10 / 19", "Completion", "Write completion record without another test"]]
    table(doc, ["Code cell / notebook position", "Purpose", "What to explain"], mapping, [1.1,1.4,4.5], font_size=10)
    qa(doc, "Why does model fit set shuffle to False?", "The tf.data training dataset already shuffles with a fixed seed and reshuffles each epoch. fit does not do an additional array shuffle. Validation and test are not shuffled for fitting (Keras, n.d.-c).")
    qa(doc, "What does argmax with axis one do?", "Predictions have one row per example and seven columns. argmax along axis one chooses the largest class score in each row, producing integer class IDs 0 to 6.")
    qa(doc, "What is steps per execution 32?", "A compiled execution call processes up to 32 training steps to reduce Python overhead. Gradient updates still occur by batch. This is not batch size 3,200 or 32 epochs. The setting stays fixed across runs.")
    qa(doc, "What happens during Restart Kernel and Run All?", "The notebook verifies the study and saved run signatures, loads matching completed runs, and loads the saved final assessment. It does not retrain or rescore test data on a normal rerun. A fresh kernel rerun was checked.")
    qa(doc, "What do the hashes and test marker prove?", "Hashes identify saved source, data, splits and models and prevent incompatible cache reuse. The test marker stops automatic repetition after an interrupted final phase. They do not prove scientific validity or permit bypassing a failed check.")
    qa(doc, "What should we do if asked to run one cell live?", "Open the prepared notebook in the project folder and select the Group 8 kernel. Explain dependencies before running a cell in order. Use the saved assessment for results. Do not delete guards or rerun the test to make a demonstration work.")

    review_page(doc, "Rehearse the talk and difficult questions")
    table(doc, ["Slide", "Topic", "Seconds", "Speaker"], [[i,title,seconds,role] for i,(title,seconds,role) in enumerate(SLIDES,1)], [.5,3.9,.7,1.9], font_size=10)
    para(doc, "Total talk 10 minutes. Reserve the remaining five minutes for questions. These speaking roles are suggestions; add names after your group agrees. Each member must understand the full notebook.")
    qa(doc, "How did AI contribute and what did members do?", "The assistant prepared research, code, execution, analysis and draft materials. Each member should state the checks, edits and practice they personally completed. Follow the instructor's AI policy; do not claim human coding or review that did not happen.")
    qa(doc, "Why not pick a model from the test scores?", "That would turn the test set into another tuning set. We selected R1 from validation, froze it, and then made one final evaluate call. Separate predictions from that same fixed model support the required errors and class metrics.")
    qa(doc, "Why did we not report test scores for every model?", "Testing all candidates would invite test driven selection and violate the declared one final assessment. We compare the runs on validation and report the selected model's test result.")
    qa(doc, "What can improve in a future study?", "Test additional seeds, investigate learning schedules or longer training with validation, and assess unseen geographic areas. R6 reached the 50 epoch cap. Any new model choice after seeing these test outcomes needs a new evaluation plan.")
    doc.add_heading("Three practice sessions", level=2)
    bullets(doc, ["First session  Explain a page outside your lead role and ask two follow ups.",
                  "Second session  Rehearse the 10 minute talk and random notebook questions.",
                  "Before presentation  Check the laptop projector files and offline data cache. Open the notebook and both Word guides. Keep final results saved."])

    review_page(doc, "References")
    add_references(doc)
    path = OUT / "Group8_Presentation_Review_and_QA.docx"
    doc.save(path)
    return path

if __name__ == "__main__":
    model_png, recall_png = build_visuals()
    outputs = [make_content(model_png, recall_png), make_review(model_png, recall_png)]
    result = {"outputs": [str(path.relative_to(ROOT)) for path in outputs],
              "planned_slides": len(SLIDES), "talk_seconds": sum(s for _,s,_ in SLIDES),
              "practice_questions": question_count, "new_model_or_test_calls": 0,
              "visuals": [str(p.relative_to(ROOT)) for p in [model_png,recall_png]]}
    (ART / "presentation_docs_manifest.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps(result,indent=2))
