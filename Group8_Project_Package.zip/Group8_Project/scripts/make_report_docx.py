"""Render the shared academic report content as editable Word paragraphs and tables."""
from html.parser import HTMLParser
from pathlib import Path
from subprocess import run
from tempfile import TemporaryDirectory

from docx import Document
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.shared import Inches, Pt, RGBColor
from reportlab.pdfgen import canvas
from reportlab.platypus import Image, PageBreak, Paragraph, Table

from make_report import ConfusionChart, H, MARGIN, ROOT, W, WIDTH, members, story

POPPLER = Path(r"C:\Users\Beo\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe")


class InlineText(HTMLParser):
    """Map the report's limited inline markup to Word runs and hyperlinks."""

    def __init__(self, paragraph):
        super().__init__()
        self.paragraph = paragraph
        self.bold = False
        self.italic = False
        self.link = None

    def handle_starttag(self, tag, attrs):
        if tag == "b":
            self.bold = True
        elif tag == "i":
            self.italic = True
        elif tag == "br":
            self.paragraph.add_run().add_break()
        elif tag == "link":
            self.link = dict(attrs)["href"]

    def handle_endtag(self, tag):
        if tag == "b":
            self.bold = False
        elif tag == "i":
            self.italic = False
        elif tag == "link":
            self.link = None

    def handle_data(self, value):
        if self.link:
            link = OxmlElement("w:hyperlink")
            link.set(qn("r:id"), self.paragraph.part.relate_to(self.link, RT.HYPERLINK, is_external=True))
            link_run = OxmlElement("w:r")
            content = OxmlElement("w:t")
            content.text = value
            link_run.append(content)
            link.append(link_run)
            self.paragraph._p.append(link)
        else:
            result = self.paragraph.add_run(value)
            if self.bold:
                result.bold = True
            if self.italic:
                result.italic = True


def style(doc, name, size, leading, after, *, bold=False, before=0, keep=False):
    styles = doc.styles
    item = styles[name] if name in styles else styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
    item.base_style = styles["Normal"] if name != "Normal" else None
    item.font.name = "Times New Roman"
    fonts = item.element.find(".//" + qn("w:rFonts"))
    for theme in ("asciiTheme", "hAnsiTheme", "eastAsiaTheme", "cstheme"):
        fonts.attrib.pop(qn("w:" + theme), None)
    item.font.size = Pt(size)
    item.font.color.rgb = RGBColor(0, 0, 0)
    item.font.bold = bold
    item.font.italic = False
    fmt = item.paragraph_format
    fmt.space_before = Pt(before)
    fmt.space_after = Pt(after)
    fmt.line_spacing = Pt(leading)
    fmt.keep_with_next = keep
    fmt.keep_together = True
    border = item.element.find(".//" + qn("w:pBdr"))
    if border is not None:
        border.getparent().remove(border)
    return item


def insert_table(doc, source):
    data = source._cellvalues
    result = doc.add_table(rows=len(data), cols=len(data[0]))
    result.autofit = False
    widths = source._argW
    for column, width in zip(result.columns, widths):
        column.width = Pt(width)
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        line = OxmlElement("w:" + edge)
        line.set(qn("w:val"), "single")
        line.set(qn("w:sz"), "4")
        line.set(qn("w:color"), "D9D9D9")
        borders.append(line)
    result._tbl.tblPr.append(borders)
    result.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
    for index, (row, values) in enumerate(zip(result.rows, data)):
        row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
        for cell, value, width in zip(row.cells, values, widths):
            cell.width = Pt(width)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            paragraph = cell.paragraphs[0]
            paragraph.style = doc.styles["Report Table Header" if index == 0 else "Report Table Text"]
            InlineText(paragraph).feed(value.text)
            if index == 0:
                shade = OxmlElement("w:shd")
                shade.set(qn("w:fill"), "EFEFEF")
                cell._tc.get_or_add_tcPr().append(shade)


def matrix_png(matrix, directory):
    stem = Path(directory) / "matrix"
    pdf = canvas.Canvas(str(stem.with_suffix(".pdf")), pagesize=(matrix.width, matrix.height))
    matrix.drawOn(pdf, 0, 0)
    pdf.save()
    run([str(POPPLER), "-singlefile", "-r", "180", "-png", str(stem.with_suffix(".pdf")), str(stem)],
        check=True, capture_output=True)
    return stem.with_suffix(".png")


def build():
    doc = Document()
    doc.core_properties.title = "Forest Cover Type Classification with Dense Neural Networks"
    doc.core_properties.author = ", ".join(members)
    section = doc.sections[0]
    section.page_width, section.page_height = Pt(W), Pt(H)
    section.left_margin = section.right_margin = Pt(MARGIN)
    section.top_margin, section.bottom_margin = Pt(38), Pt(46)
    section.footer_distance = Pt(23)
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    footer._p.append(field)
    style(doc, "Normal", 11, 13, 6)
    style(doc, "Title", 27, 29, 11, bold=True, keep=True)
    style(doc, "Heading 1", 23, 26, 10, bold=True, keep=True)
    style(doc, "Heading 2", 13, 15, 4, bold=True, before=7, keep=True)
    style(doc, "Report Author", 11, 14, 10)
    style(doc, "Report Small", 10, 12, 6)
    style(doc, "Report Note", 9.5, 11, 6, before=4)
    style(doc, "Report Display Label", 10, 11.5, 4, before=4, keep=True)
    style(doc, "Report Table Text", 9, 11, 2, before=2)
    style(doc, "Report Table Header", 9, 11, 2, bold=True, before=2)
    heading = style(doc, "Report References Heading", 12, 24, 0, bold=True, keep=True)
    heading.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    reference = style(doc, "APA Reference", 12, 24, 0)
    reference.paragraph_format.left_indent = Inches(.5)
    reference.paragraph_format.first_line_indent = Inches(-.5)
    names = {"Title":"Title", "H1":"Heading 1", "H2":"Heading 2", "Body":"Normal",
             "Author":"Report Author", "Small":"Report Small", "Caption":"Report Note",
             "DisplayLabel":"Report Display Label", "ReferencesHeading":"Report References Heading",
             "APA7Reference":"APA Reference"}
    alt_text = iter([
        "Counts of all seven cover types. Lodgepole Pine and Spruce/Fir account for 85.22 percent.",
        "Training and validation loss across 13 epochs. Validation loss reaches its minimum at epoch 11.",
        "Seven by seven normalized confusion matrix. Douglas-fir has the lowest diagonal recall.",
    ])
    next_page = False
    after_table = False
    with TemporaryDirectory(prefix="forest-report-") as directory:
        for item in story:
            if isinstance(item, PageBreak):
                next_page = True
            elif isinstance(item, Paragraph):
                paragraph = doc.add_paragraph(style=names[item.style.name])
                if after_table:
                    paragraph.paragraph_format.space_before = Pt(4)
                    after_table = False
                if next_page:
                    paragraph.paragraph_format.page_break_before = True
                    next_page = False
                InlineText(paragraph).feed(item.text)
                if item.style.name == "ReferencesHeading":
                    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            elif isinstance(item, Table):
                insert_table(doc, item)
                after_table = True
            elif isinstance(item, (Image, ConfusionChart)):
                file = item.filename if isinstance(item, Image) else matrix_png(item, directory)
                width = item.drawWidth if isinstance(item, Image) else WIDTH
                paragraph = doc.add_paragraph()
                paragraph.paragraph_format.line_spacing = 1
                paragraph.paragraph_format.space_after = Pt(0)
                paragraph.paragraph_format.keep_with_next = True
                paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                picture = paragraph.add_run().add_picture(str(file), width=Pt(width))
                picture._inline.docPr.set("descr", next(alt_text))
        output = ROOT / "output" / "docx" / "Group8_Academic_Report.docx"
        output.parent.mkdir(parents=True, exist_ok=True)
        doc.save(output)
    print("Created", output)


if __name__ == "__main__":
    build()
