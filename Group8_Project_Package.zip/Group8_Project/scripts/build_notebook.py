"""Build the self-contained notebook and optionally execute it with saved outputs."""
import argparse
import ast
import hashlib
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "Group8_Study.py").read_text(encoding="utf-8")
source_hash = hashlib.sha256(source.encode()).hexdigest()
pieces = re.split(r"^# %%([^\n]*)\n", source, flags=re.MULTILINE)
cells = []
for i in range(1, len(pieces), 2):
    kind, content = pieces[i], pieces[i + 1].strip()
    markdown = "[markdown]" in kind
    if markdown:
        content = ast.literal_eval(content).strip()
    else:
        ast.parse(content)
        content = content.replace("SOURCE_SHA256_PLACEHOLDER", source_hash)
    cell = {"cell_type": "markdown" if markdown else "code", "metadata": {},
            "id": hashlib.sha256(f"{i}:{content}".encode()).hexdigest()[:12],
            "source": content}
    if not markdown:
        cell.update(execution_count=None, outputs=[])
    cells.append(cell)
notebook = {"cells": cells, "metadata": {"kernelspec": {"display_name": "Python 3 (Group 8)", "language": "python", "name": "python3"},
             "language_info": {"name": "python", "version": "3.12"}}, "nbformat": 4, "nbformat_minor": 5}
parser = argparse.ArgumentParser()
parser.add_argument("--execute", action="store_true")
parser.add_argument("--output", default="Group8_Notebook.ipynb")
args = parser.parse_args()
path = ROOT / args.output
if path.exists():
    raise SystemExit("Preserve the existing notebook. Use --output with a new filename for a reproduction copy.")
path.write_text(json.dumps(notebook, indent=1), encoding="utf-8")
print("Built", path.name, "with", len(cells), "cells", flush=True)
if args.execute:
    import nbformat
    from nbclient import NotebookClient
    local_jupyter = ROOT / ".jupyter"
    kernel_dir = local_jupyter / "kernels" / "python3"
    kernel_dir.mkdir(parents=True, exist_ok=True)
    (local_jupyter / "runtime").mkdir(exist_ok=True)
    (kernel_dir / "kernel.json").write_text(json.dumps({"argv": [sys.executable, "-m", "ipykernel_launcher", "-f", "{connection_file}"],
        "display_name": "Python 3 (Group 8)", "language": "python"}), encoding="utf-8")
    os.environ["JUPYTER_PATH"] = str(local_jupyter)
    os.environ["JUPYTER_RUNTIME_DIR"] = str(ROOT / ".jupyter" / "runtime")
    nb = nbformat.read(path, as_version=4)
    def started(cell_index, **kwargs):
        print("Executing cell", cell_index + 1, flush=True)
    def completed(**kwargs):
        nbformat.write(nb, path)
    client = NotebookClient(nb, timeout=7200, kernel_name="python3",
                            resources={"metadata": {"path": str(ROOT)}},
                            on_cell_start=started, on_cell_executed=completed)
    try:
        client.execute()
    finally:
        nbformat.write(nb, path)
    print("Notebook execution complete", flush=True)
