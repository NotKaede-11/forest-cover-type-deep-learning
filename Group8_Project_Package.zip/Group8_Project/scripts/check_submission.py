"""Verify saved evidence and submission files without another model/test call."""
import ast
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
from sklearn.metrics import accuracy_score, balanced_accuracy_score, confusion_matrix, f1_score

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / "artifacts"

def load(name):
    return json.loads((ART / name).read_text(encoding="utf-8"))

def file_hash(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

manifest = load("study_manifest.json")
assert file_hash(ROOT / "Group8_Study.py") == manifest["source_sha256"]
splits = np.load(ART / "split_indices.npz")
ids = [splits[name] for name in ["train", "validation", "test"]]
assert len(np.unique(np.concatenate(ids))) == sum(len(x) for x in ids) == 581012
for name, values in zip(["train", "validation", "test"], ids):
    assert hashlib.sha256(values.tobytes()).hexdigest() == manifest["split_hashes"][name]
records = [load(f"runs/R{i}/metrics.json") for i in range(9)]
for i, row in enumerate(records):
    expected = {**manifest["baseline"], **manifest["runs"][i][2]}
    assert row["config"] == expected
    assert sum(row["config"][k] != manifest["baseline"][k] for k in expected) == (0 if i == 0 else 1)
    assert row["study_id"] == manifest["study_id"]
    assert file_hash(ART / f"runs/R{i}/model.keras") == row["model_sha256"]
    with (ART / f"runs/R{i}/history.csv").open(newline="", encoding="utf-8") as stream:
        history = list(csv.DictReader(stream))
    assert len(history) == row["epochs_run"]
    best_epoch = min(range(len(history)), key=lambda j: float(history[j]["val_loss"])) + 1
    assert row["selected_epoch"] == best_epoch
    assert abs(float(history[best_epoch-1]["val_loss"]) - row["val_loss"]) < 1e-5
    assert abs(float(history[best_epoch-1]["val_accuracy"]) - row["val_accuracy"]) < 1e-5
winner = min(records, key=lambda row: (-row["val_macro_f1"], -row["val_accuracy"], row["val_loss"], row["parameters"], row["run_id"]))
selection, final = load("selection.json"), load("final_test_metrics.json")
assert winner["run_id"] == selection["run_id"] == final["run_id"]
assert final["evaluate_calls"] == 1
assert selection["frozen_before_test"] <= load("final_test_started.json")["started"] <= final["finished"]
assert file_hash(ART / "Group8_Selected_Model.keras") == selection["model_sha256"] == final["model_sha256"]
assert file_hash(ART / "final_test_probabilities.npz") == final["probabilities_sha256"]
saved = np.load(ART / "final_test_probabilities.npz")
assert np.array_equal(saved["row_ids"], ids[2])
probabilities = saved["probabilities"]
assert probabilities.shape == (len(ids[2]), 7)
assert np.isfinite(probabilities).all() and (probabilities >= 0).all()
assert np.allclose(probabilities.sum(axis=1), 1, atol=1e-5)
with (ART / "Group8_Test_Predictions.csv").open(newline="", encoding="utf-8") as stream:
    predictions = list(csv.DictReader(stream))
true = np.array([int(row["true_id"]) for row in predictions])
predicted = np.array([int(row["predicted_id"]) for row in predictions])
assert np.array_equal(predicted, probabilities.argmax(axis=1))
assert np.array_equal(np.array([int(row["row_id"]) for row in predictions]), ids[2])
assert abs(accuracy_score(true, predicted) - final["accuracy"]) < 1e-12
assert abs(f1_score(true, predicted, average="macro") - final["macro_f1"]) < 1e-12
assert abs(balanced_accuracy_score(true, predicted) - final["balanced_accuracy"]) < 1e-12
assert confusion_matrix(true, predicted).sum() == final["test_rows"]
with (ART / "Group8_Five_Errors.csv").open(newline="", encoding="utf-8") as stream:
    errors = list(csv.DictReader(stream))
assert len(errors) >= 5
index = {int(row["row_id"]): row for row in predictions}
for error in errors:
    source = index[int(error["row_id"])]
    assert source["true_id"] != source["predicted_id"]
    assert source["true_id"] == error["true_id"] and source["predicted_id"] == error["predicted_id"]
nb = json.loads((ROOT / "Group8_Notebook.ipynb").read_text(encoding="utf-8"))
code = [cell for cell in nb["cells"] if cell["cell_type"] == "code"]
assert all(cell["execution_count"] is not None for cell in code)
assert all(output["output_type"] != "error" for cell in code for output in cell["outputs"])
for cell in code:
    text = "".join(cell["source"]) if isinstance(cell["source"], list) else cell["source"]
    ast.parse(text)
assert [cell["execution_count"] for cell in code] == list(range(1, len(code) + 1))
assert len(list((ROOT / "figures").glob("Group8_*.png"))) == 4
assert not list(ROOT.glob("*.pptx")), "PowerPoint belongs to the group."
check = {"passed": True, "study_id": manifest["study_id"], "runs_checked": 9,
         "executed_code_cells": len(code), "test_rows_checked": len(true),
         "selected_run": winner["run_id"], "test_metrics_recomputed_from_saved_predictions": True,
         "new_model_or_test_calls": 0}
(ART / "verification.json").write_text(json.dumps(check, indent=2), encoding="utf-8")
print(json.dumps(check, indent=2))
