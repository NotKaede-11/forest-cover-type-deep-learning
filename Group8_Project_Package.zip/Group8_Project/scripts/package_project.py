"""Package the portable project and verify the archive against file hashes."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
required = ["Group8_Notebook.ipynb", "Group8_Study.py", "Group8_Finals_Project.pdf", "README.md",
            "requirements.txt", "requirements-lock.txt", "output/pdf/Group8_Academic_Report.pdf",
            "output/pdf/Group8_Report.pdf",
            "output/pptx/Group8_Case_Study.pptx",
            "output/docx/Group8_Academic_Report.docx",
            "output/docx/Group8_PPT_Content_Pack.docx",
            "output/docx/Group8_Presentation_Review_and_QA.docx"]
files = [ROOT / name for name in required]
for folder in ["artifacts", "docs", "figures", "scripts", "data"]:
    files.extend(path for path in (ROOT / folder).rglob("*") if path.is_file()
                 and "__pycache__" not in path.parts
                 and path.name != "package_manifest.json"
                 and not path.name.endswith(".tmp"))
assert all(path.exists() for path in files)
files = sorted(set(files))
hashes = {path.relative_to(ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
manifest = ROOT / "artifacts" / "package_manifest.json"
manifest.write_text(json.dumps({"files": hashes, "note": "Machine-specific .venv/.jupyter and temporary renders are excluded."}, indent=2), encoding="utf-8")
archive_path = ROOT / "output" / "Group8_Project_Package.zip"
with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
    for path in [*files, manifest]:
        archive.write(path, "Group8_Project/" + path.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for relative, expected in hashes.items():
        assert hashlib.sha256(archive.read("Group8_Project/" + relative)).hexdigest() == expected
print("Verified", len(files) + 1, "files in", archive_path, f"({archive_path.stat().st_size/1024**2:.1f} MiB)")
