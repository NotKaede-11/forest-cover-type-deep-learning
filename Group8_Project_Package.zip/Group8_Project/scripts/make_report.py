"""Create the five-page grayscale report from saved experiment evidence only."""
import csv
import hashlib
import json
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (BaseDocTemplate, Flowable, Frame, Image,
                               PageBreak, PageTemplate, Paragraph, Spacer, Table, TableStyle)

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / "artifacts"
OUT = ROOT / "output" / "pdf"
OUT.mkdir(parents=True, exist_ok=True)

def read_json(name):
    return json.loads((ART / name).read_text(encoding="utf-8"))

def read_csv(name):
    with (ART / name).open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))

final = read_json("final_test_metrics.json")
selection = read_json("selection.json")
analysis = read_json("analysis_summary.json")
manifest = read_json("study_manifest.json")
environment = read_json("environment.json")
quality = read_json("data_quality.json")
runs = read_csv("Group8_Experiment_Log.csv")
classes = read_csv("Group8_Per_Class_Test_Metrics.csv")
splits = read_csv("Group8_Split_Metrics.csv")
errors = read_csv("Group8_Five_Errors.csv")
split_counts = read_csv("split_class_counts.csv")
winner = next(row for row in runs if row["run_id"] == selection["run_id"])
baseline = next(row for row in runs if row["run_id"] == "R0")
assert final["evaluate_calls"] == 1
assert len(runs) == 9 and len(errors) >= 5
assert final["model_sha256"] == selection["model_sha256"]
W, H = A4
MARGIN = 47
WIDTH = W - 2*MARGIN
styles = {
    "title": ParagraphStyle("Title", fontName="Times-Bold", fontSize=28, leading=29, spaceAfter=12),
    "h1": ParagraphStyle("H1", fontName="Times-Bold", fontSize=24, leading=27, spaceAfter=12, keepWithNext=True),
    "h2": ParagraphStyle("H2", fontName="Times-Bold", fontSize=13, leading=15, spaceBefore=9, spaceAfter=4, keepWithNext=True),
    "body": ParagraphStyle("Body", fontName="Times-Roman", fontSize=11, leading=14, spaceAfter=7),
    "author": ParagraphStyle("Author", fontName="Times-Roman", fontSize=11, leading=14, spaceAfter=13),
    "small": ParagraphStyle("Small", fontName="Times-Roman", fontSize=10, leading=12.5, spaceAfter=7),
    "caption": ParagraphStyle("Caption", fontName="Times-Roman", fontSize=9.5, leading=11.5, spaceBefore=3, spaceAfter=8),
    "display": ParagraphStyle("DisplayLabel", fontName="Times-Roman", fontSize=10, leading=12, spaceBefore=5, spaceAfter=4, keepWithNext=True),
    "cell": ParagraphStyle("Cell", fontName="Helvetica", fontSize=8.3, leading=10.3),
    "cellsmall": ParagraphStyle("CellSmall", fontName="Helvetica", fontSize=7.8, leading=9.5),
    "head": ParagraphStyle("Head", fontName="Helvetica-Bold", fontSize=8.1, leading=10),
    "references_heading": ParagraphStyle("ReferencesHeading", fontName="Times-Bold", fontSize=12, leading=24, alignment=TA_CENTER, spaceAfter=0),
    "reference": ParagraphStyle("APA7Reference", fontName="Times-Roman", fontSize=12, leading=24,
                                leftIndent=36, firstLineIndent=-36, spaceBefore=0, spaceAfter=0),
}
story = []

def p(text, style="body"):
    story.append(Paragraph(text, styles[style]))

def heading(text):
    p(text, "h2")

def label(kind, number, title):
    p(f"<b>{kind} {number}</b><br/><i>{title}</i>", "display")

def note(text):
    p(f"<i>Note.</i> {text}", "caption")

def table(headers, rows, widths, small=False):
    cell_style = styles["cellsmall" if small else "cell"]
    data = [[Paragraph(escape(str(x)), styles["head"]) for x in headers]]
    data += [[Paragraph(escape(str(x)), cell_style) for x in row] for row in rows]
    t = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
    t.setStyle(TableStyle([
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("LINEABOVE", (0,0), (-1,0), 0.8, colors.black),
        ("LINEBELOW", (0,0), (-1,0), 0.5, colors.black),
        ("LINEBELOW", (0,-1), (-1,-1), 0.6, colors.black),
        ("LEFTPADDING", (0,0), (-1,-1), 4),
        ("RIGHTPADDING", (0,0), (-1,-1), 4),
        ("TOPPADDING", (0,0), (-1,-1), 3),
        ("BOTTOMPADDING", (0,0), (-1,-1), 3),
    ]))
    story.append(t)
    story.append(Spacer(1, 5))

def figure(filename, width=WIDTH, max_height=None):
    path = ROOT / "figures" / filename
    iw, ih = ImageReader(str(path)).getSize()
    height = width * ih / iw
    if max_height and height > max_height:
        width *= max_height / height
        height = max_height
    story.append(Image(str(path), width=width, height=height, hAlign="CENTER"))

class ConfusionChart(Flowable):
    """Readable vector chart from saved counts; no additional model evaluation."""
    def __init__(self):
        super().__init__()
        self.width, self.height = WIDTH, 218
    def draw(self):
        canvas = self.canv
        matrix_rows = read_csv("Group8_Confusion_Normalized.csv")
        names = [row["cover_type"] for row in classes]
        short = ["Spruce/Fir", "Lodgepole", "Ponderosa", "Cotton/W", "Aspen", "Douglas", "Krummholz"]
        left, bottom, cell = 172, 50, 24
        canvas.setFillColor(colors.black)
        for i, row in enumerate(matrix_rows):
            for j, name in enumerate(names):
                value = float(row[name])
                shade = 1 - value*0.95
                x, y = left + j*cell, bottom + (6-i)*cell
                canvas.setFillColor(colors.Color(shade, shade, shade))
                canvas.rect(x, y, cell, cell, stroke=0, fill=1)
                canvas.setFillColor(colors.white if value > .5 else colors.black)
                canvas.setFont("Helvetica", 8.3)
                canvas.drawCentredString(x + cell/2, y + cell/2 - 3, f"{value:.2f}")
        canvas.setFillColor(colors.black)
        canvas.setFont("Helvetica", 8)
        for i, name in enumerate(names):
            canvas.drawRightString(left - 6, bottom + (6-i)*cell + cell/2 - 3, name)
        for j, name in enumerate(short):
            canvas.saveState()
            canvas.translate(left + j*cell + cell/2, bottom - 5)
            canvas.rotate(45)
            canvas.drawRightString(0, 0, name)
            canvas.restoreState()
        canvas.setFont("Helvetica", 8.5)
        canvas.drawCentredString(left + 3.5*cell, 2, "Predicted class")

def pct(value):
    return f"{float(value)*100:.2f}%"

def num(value):
    return f"{float(value):.4f}"

def page():
    story.append(PageBreak())

config = selection["config"]
architecture = " - ".join(str(v) for v in [54, *config["units"], 7])
total_minutes = sum(float(row["training_seconds"]) for row in runs)/60
selected_train = next(row for row in splits if row["split"] == "train")
selected_val = next(row for row in splits if row["split"] == "validation")
gap_pp = analysis["train_validation_accuracy_gap"]*100
worst = min(classes, key=lambda row: float(row["recall"]))
best = max(classes, key=lambda row: float(row["recall"]))
members = ["Beomarc Andrew D. Cartoneros", "Matthew R. Lopez",
           "Axiel Achia M. Escabal", "Alon U. Villanueva"]

# Page 1: question, source and preprocessing.
p("Forest Cover Type Classification<br/>with Dense Neural Networks", "title")
p(f"{members[0]} and {members[1]}<br/>{members[2]} and {members[3]}", "author")
heading("Abstract")
p(f"We compared nine dense neural networks on 581,012 land records from four Colorado wilderness areas. Validation macro-F1 selected a network with two 100-unit hidden layers. The frozen model reached {pct(final['accuracy'])} accuracy and {num(final['macro_f1'])} macro-F1 on 58,102 held-out records. Recall ranged from 64.42% for Douglas-fir to 92.77% for Lodgepole Pine. The findings support screening similar records with human review. Performance in new regions remains unmeasured.")
heading("1. Dataset and preprocessing")
p("The task is to predict one of seven cover types for each 30 × 30 metre cell in Roosevelt National Forest. U.S. Forest Service records supplied the labels. The 54 cartographic inputs (Table 1) describe terrain and land characteristics (Blackard, 1998, 1999).")
label("Table", 1, "Input Groups and Preprocessing")
table(["Input group", "Columns", "Treatment"], [
    ["Elevation, aspect, slope, distances and hillshade", "10 numeric", "Fit scaling on training rows only"],
    ["Wilderness designation", "4 binary", "Preserve 0/1 encoding"],
    ["Soil / ecological landtype designation", "40 binary", "Preserve 0/1 encoding"]], [230, 75, WIDTH-305])
p("Spruce/Fir and Lodgepole Pine make up 85.22% of the dataset (Figure 1). Stratified splits retained the natural proportions and reserved 464,809 rows for training, 58,101 for validation and 58,102 for testing (seeds 42 and 43).")
label("Figure", 1, "Forest Cover Type Counts in the Full Dataset")
figure("Group8_Class_Counts.png", max_height=162)
note("Cottonwood/Willow is the smallest class at 0.47% of all cells.")
p("We mapped labels 1–7 to 0–6, verified the binary indicators and found no missing or nonfinite values. Row IDs were disjoint, and no 64-bit feature hash repeated or appeared across splits. We fitted StandardScaler to the ten numeric columns on training rows and applied it across partitions (scikit-learn developers, n.d.-b).")

# Page 2: full experiment evidence and selected history.
page()
p("2. Model and Experiments", "h1")
p("The baseline uses 54 inputs, two 50-unit ReLU layers and seven softmax outputs (5,657 parameters). We used Adam at learning rate 0.001, sparse categorical cross-entropy, batch 100, a 50-epoch cap, and early stopping on validation loss with patience 2 and best-weight restoration (Keras, n.d.-b, n.d.-c). Each run starts with fresh model, optimizer and callback state.")
p("Each variant changes one setting relative to R0 (Table 2). The runs share the split, seed policy and epoch cap. We ranked restored checkpoints by validation macro-F1, then accuracy, lower loss, fewer parameters and run ID. Macro-F1 weights every class equally.")
label("Table", 2, "Validation Results for Nine Controlled Runs")
table(["Run", "Change from R0", "Epochs", "Val. loss", "Val. acc.", "Macro-F1"],
      [[row["run_id"], row["description"], f"{row['epochs_run']} / {row['selected_epoch']}", num(row["val_loss"]), pct(row["val_accuracy"]), num(row["val_macro_f1"])] for row in runs],
      [30, 176, 52, 68, 72, WIDTH-398], small=True)
note("Epochs are shown as executed / restored. All scores describe restored weights.")
p(f"R1 had {int(winner['parameters']):,} parameters and led R6 by 0.0002 macro-F1. This single run per setting leaves uncertainty about the ranking under other seeds. Figure 2 shows R1’s training history.")
label("Figure", 2, "Training and Validation Loss for R1")
figure("Group8_Best_Loss_Curve.png", max_height=153)
note("Validation loss reached its minimum at epoch 11. Training ended after epoch 13 and restored the epoch 11 weights.")
heading("Class weighting and dropout")
weight_row = next(row for row in runs if row["run_id"] == "R7")
dropout_row = next(row for row in runs if row["run_id"] == "R8")
p(f"R7 weighted classes inversely to their training frequency. Mean class recall rose from {pct(baseline['val_balanced_accuracy'])} to {pct(weight_row['val_balanced_accuracy'])}, while macro-F1 fell from {num(baseline['val_macro_f1'])} to {num(weight_row['val_macro_f1'])}. R8 randomly dropped 20% of hidden activations during training (Keras, n.d.-a). Its macro-F1 fell to {num(dropout_row['val_macro_f1'])}.")

# Page 3: held-out results, class support and confusion.
page()
p("3. Held-Out Results", "h1")
p("After selection, one final model.evaluate call measured test loss and accuracy with the frozen R1 model. Its saved predictions supplied the per-class results (Table 4) and error analysis. Table 3 compares performance across the three partitions.")
label("Table", 3, "Frozen Model Performance by Partition")
table(["Partition", "Rows", "Accuracy", "Macro-F1", "Balanced acc."],
      [[row["split"].capitalize(), f"{manifest['sizes'][row['split']]:,}", pct(row["accuracy"]), num(row["macro_f1"]), pct(row["balanced_accuracy"])] for row in splits],
      [100, 86, 100, 100, WIDTH-386])
label("Table", 4, "Precision, Recall, and F1 by True Cover Type")
table(["True cover type", "Test support", "Precision", "Recall", "F1"],
      [[row["cover_type"], f"{int(float(row['support'])):,}", num(row["precision"]), num(row["recall"]), num(row["f1-score"])] for row in classes],
      [164, 90, 87, 87, WIDTH-428])
p("Recall is the fraction of a true class predicted correctly. Balanced accuracy averages the seven recalls, and macro-F1 averages the seven class F1 scores (scikit-learn developers, n.d.-a). Figure 3 shows which labels the model confused.")
label("Figure", 3, "Row-Normalized Confusion Matrix for the Test Set")
story.append(ConfusionChart())
note("Rows are true classes. Columns are predictions. The diagonal gives recall. Cotton/W denotes Cottonwood/Willow.")
p(f"Training accuracy exceeded validation accuracy by {gap_pp:.2f} percentage points. The small gap describes this split. Douglas-fir had the lowest recall ({pct(worst['recall'])}), and always predicting the largest class would yield {pct(analysis['majority_class_test_reference_accuracy'])} test accuracy.")

# Page 4: concrete wrong cases and restrained explanations.
page()
p("4. Error Analysis and Discussion", "h1")
p(f"The model misclassified {analysis['test_error_count']:,} of {final['test_rows']:,} test cells. Table 5 shows the lowest-row-ID mistake from each of the first five true classes with errors, using the rule fixed before test analysis.")
label("Table", 5, "Five Misclassified Test Cells")
table(["Row ID", "True cover", "Predicted cover", "Elev. m", "Slope", "Max score"],
      [[row["row_id"], row["true_class"], row["predicted_class"], row["elevation_m"], row["slope_degrees"] + " deg", pct(row["maximum_softmax"])] for row in errors[:5]],
      [49, 126, 126, 58, 58, WIDTH-417])
note("Max score is the largest softmax output. Calibration was outside the scope of the study.")
heading("Recorded conditions and possible explanations")
for i, row in enumerate(errors[:5], 1):
    true_count = int(next(c for c in split_counts if c["cover_type"] == row["true_class"])["train"])
    predicted_count = int(next(c for c in split_counts if c["cover_type"] == row["predicted_class"])["train"])
    explanations = {
        0: "Rows 115 and 444 share Rawah and soil indicator 29. That overlap may contribute to the Spruce/Fir and Lodgepole Pine confusion.",
        1: "The model makes the reverse error at 3,004 m. Both cover types occur in Rawah (Blackard, 1999), so wilderness alone leaves the class ambiguous.",
        2: "The cell has a recorded water distance of 0 m. Both classes occur in Cache la Poudre (Blackard, 1999), where shared conditions may make them harder to separate.",
        3: f"This cell lies 42 m from water. Training had {true_count:,} Cottonwood/Willow cells versus {predicted_count:,} Ponderosa Pine cells, an imbalance that may contribute to the error.",
        4: f"Both classes occur in Rawah (Blackard, 1999). Training had {predicted_count:,} Lodgepole Pine cells versus {true_count:,} Aspen cells. Shared area and unequal representation may contribute."
    }
    explanation = explanations.get(int(row["true_id"]), "The recorded terrain may overlap between classes; no local causal attribution was computed.")
    p(f"<b>Case {i}, row {row['row_id']}.</b> {explanation}")
p("These explanations are hypotheses based on recorded features. Establishing a cause would require local attribution or field evidence.")
heading("Use and limits")
p("Use the model to screen records similar to the study data, with human review of predictions and particular attention to Douglas-fir. The random split measures performance within the source dataset. Nearby cells may share ecological conditions across partitions. Testing transfer would require holding out a geographic area or collecting external data.")
heading("Reproducibility and AI disclosure")
p(f"The notebook records the fixed seeds, split indices, settings and saved checkpoints. The nine runs took {total_minutes:.1f} minutes on Windows CPU with Python {environment['python']} and TensorFlow {environment['packages']['tensorflow']}. An AI assistant supported research, coding, execution, analysis, writing and slide preparation.", "small")

# Page 5: APA 7 reference list, separate from the report text.
page()
p("References", "references_heading")
refs = [
    ("Blackard, J. A. (1998). <i>Covertype</i> [Data set]. UCI Machine Learning Repository.", "https://doi.org/10.24432/C50K5N"),
    ("Blackard, J. A. (1999, December 7). <i>The Forest CoverType dataset</i> [Data set documentation]. UCI Machine Learning Repository.", "https://archive.ics.uci.edu/ml/machine-learning-databases/covtype/covtype.info"),
    ("Keras. (n.d.-a). <i>Dropout layer</i>. Retrieved November 6, 2026, from", "https://keras.io/api/layers/regularization_layers/dropout/"),
    ("Keras. (n.d.-b). <i>EarlyStopping</i>. Retrieved November 6, 2026, from", "https://keras.io/api/callbacks/early_stopping/"),
    ("Keras. (n.d.-c). <i>Model training APIs</i>. Retrieved November 6, 2026, from", "https://keras.io/api/models/model_training_apis/"),
    ("scikit-learn developers. (n.d.-a). <i>classification_report</i>. scikit-learn. Retrieved November 6, 2026, from", "https://scikit-learn.org/stable/modules/generated/sklearn.metrics.classification_report.html"),
    ("scikit-learn developers. (n.d.-b). <i>Common pitfalls and recommended practices</i>. scikit-learn. Retrieved November 6, 2026, from", "https://scikit-learn.org/stable/common_pitfalls.html"),
]
for label, url in refs:
    p(f'{label} <link href="{escape(url)}" color="#000000">{escape(url)}</link>', "reference")

def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.HexColor("#444444"))
    canvas.drawRightString(W - MARGIN, 25, str(doc.page))
    canvas.restoreState()

if __name__ == "__main__":
    pdf_path = OUT / "Group8_Academic_Report.pdf"
    doc = BaseDocTemplate(str(pdf_path), pagesize=A4, leftMargin=MARGIN, rightMargin=MARGIN,
                          topMargin=38, bottomMargin=46, title="Forest Cover Type Classification",
                          author=", ".join(members), subject="Measured dense-network experiments and held-out evaluation")
    doc.addPageTemplates(PageTemplate(id="report", frames=[Frame(MARGIN, 46, WIDTH, H - 84, leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)], onPage=footer))
    doc.build(story)
    print("Created", pdf_path)
