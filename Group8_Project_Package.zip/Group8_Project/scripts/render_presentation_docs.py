"""Use the packaged DOCX renderer with a native Word PDF conversion on Windows.

The bundled renderer requires LibreOffice, which is not bundled on Windows and
is not installed here. This adapter changes only that conversion step. Word
opens our generated document read only; Poppler handles the packaged PNG loop.
"""
import importlib.util
import os
import subprocess
from pathlib import Path

SKILL = Path(r"C:\Users\Beo\.codex\plugins\cache\openai-primary-runtime\documents\26.1105.12137\skills\documents")
POPPLER = Path(r"C:\Users\Beo\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin")
os.environ["PATH"] = str(POPPLER) + os.pathsep + os.environ.get("PATH", "")
spec = importlib.util.spec_from_file_location("packaged_docx_renderer", SKILL / "render_docx.py")
renderer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(renderer)

def convert_with_word(doc_path, user_profile, convert_tmp_dir, stem, verbose):
    output = Path(convert_tmp_dir) / (stem + ".pdf")
    env = os.environ.copy()
    env["GROUP8_DOCX_INPUT"] = str(Path(doc_path).resolve())
    env["GROUP8_DOCX_PDF"] = str(output.resolve())
    script = r"""
$ErrorActionPreference = 'Stop'
$word = $null
$document = $null
try {
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $word.AutomationSecurity = 3
    $document = $word.Documents.Open($env:GROUP8_DOCX_INPUT, $false, $true, $false)
    $document.Repaginate()
    $document.Fields.Update() | Out-Null
    $pages = $document.ComputeStatistics(2)
    $document.ExportAsFixedFormat($env:GROUP8_DOCX_PDF, 17)
    Write-Output ('Word rendered ' + $pages + ' pages')
} finally {
    if ($null -ne $document) {
        $document.Close(0)
        [System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($document) | Out-Null
    }
    if ($null -ne $word) {
        if ($word.Documents.Count -eq 0) { $word.Quit() }
        [System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($word) | Out-Null
    }
}
"""
    shell = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    proc = subprocess.run([str(shell), "-NoProfile", "-NonInteractive", "-Command", script],
                          env=env, capture_output=True, text=True, timeout=120)
    if proc.returncode or not output.exists():
        raise RuntimeError("Native Word conversion failed:\n" + proc.stdout + proc.stderr)
    print(proc.stdout.strip(), flush=True)
    return str(output), proc.stdout + proc.stderr

renderer.convert_to_pdf = convert_with_word
if __name__ == "__main__":
    renderer.main()
