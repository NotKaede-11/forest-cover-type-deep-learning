"""Write measured handoff notes and finish the execution record."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / "artifacts"
def load(name):
    return json.loads((ART / name).read_text(encoding="utf-8"))
def rows(name):
    return list(csv.DictReader((ART / name).open(encoding="utf-8", newline="")))
final, selected, summary = load("final_test_metrics.json"), load("selection.json"), load("analysis_summary.json")
runs = rows("Group8_Experiment_Log.csv")
classes = rows("Group8_Per_Class_Test_Metrics.csv")
split_metrics = rows("Group8_Split_Metrics.csv")
winner = next(r for r in runs if r["run_id"] == selected["run_id"])
baseline = next(r for r in runs if r["run_id"] == "R0")
weights = next(r for r in runs if r["run_id"] == "R7")
dropout = next(r for r in runs if r["run_id"] == "R8")
pct = lambda value: f"{float(value)*100:.2f}%"
table = "\n".join(f"| {r['run_id']} | {r['description']} | {r['epochs_run']} / {r['selected_epoch']} | {float(r['val_loss']):.4f} | {pct(r['val_accuracy'])} | {float(r['val_macro_f1']):.4f} |" for r in runs)
class_table = "\n".join(f"| {r['cover_type']} | {int(float(r['support'])):,} | {pct(r['precision'])} | {pct(r['recall'])} | {float(r['f1-score']):.4f} |" for r in classes)
split_table = "\n".join(f"| {r['split']} | {pct(r['accuracy'])} | {float(r['macro_f1']):.4f} | {pct(r['balanced_accuracy'])} |" for r in split_metrics)
text = f"""# Results and reporting guide - Group 8

Actual execution completed {final['finished']}. The numbers below come from the saved logs and final predictions. They replace planning assumptions with measured evidence. Your group will create its own PowerPoint.

## Main result

Validation selected **{selected['run_id']} ({winner['description']})**. Its final test accuracy is **{pct(final['accuracy'])}**, macro-F1 **{final['macro_f1']:.4f}**, and balanced accuracy **{pct(final['balanced_accuracy'])}** on **{final['test_rows']:,}** test rows. The model made **{summary['test_error_count']:,}** errors.

The study used all 581,012 rows, with 464,809 training, 58,101 validation and 58,102 test rows. There were nine assessed runs and one separate two-epoch runtime pilot. The pilot did not evaluate the test set. The final assessment records **one model.evaluate call**; chart and class-metric checks use saved predictions.

## Experiment table to explain

| Run | One change from R0 | Epochs run / restored | Val. loss | Val. accuracy | Val. macro-F1 |
| --- | --- | --- | --- | --- | --- |
{table}

R0-R6 cover the required baseline plus six one-factor changes. R7 adds a class-weight comparison; R8 adds dropout. Every variant compares to R0. We did not accumulate changes from row to row.

The rule was fixed before assessed training: highest validation macro-F1, then validation accuracy, lower validation loss, fewer parameters and run ID. Early stopping chooses the checkpoint within each run using validation loss. The table records metrics from that restored checkpoint.

The selected configuration is `{json.dumps(selected['config'], sort_keys=True)}` with **{int(winner['parameters']):,}** parameters. It ran {winner['epochs_run']} epochs and restored epoch {winner['selected_epoch']}. A close single-seed difference does not prove one configuration is universally better.

## Results to show together

| Partition | Accuracy | Macro-F1 | Balanced accuracy |
| --- | --- | --- | --- |
{split_table}

These scores describe the same frozen checkpoint in inference mode. Training-history accuracy was accumulated while weights changed; do not substitute it into this comparison. The train-minus-validation accuracy gap is **{summary['train_validation_accuracy_gap']*100:.2f} percentage points**.

| True class | Test support | Precision | Recall | F1 |
| --- | --- | --- | --- | --- |
{class_table}

Say “recall for each class” when explaining the brief's “accuracy for each class.” A class's recall answers: of all cells truly in this class, what fraction did we label correctly? Precision answers: of cells predicted as this class, what fraction were right? Macro-F1 averages seven F1 scores equally. Balanced accuracy averages seven recalls.

## Two comparisons worth discussing

**Class weights:** R7 changed validation accuracy from {pct(baseline['val_accuracy'])} to {pct(weights['val_accuracy'])}; macro-F1 changed from {float(baseline['val_macro_f1']):.4f} to {float(weights['val_macro_f1']):.4f}. Mean class recall changed from {pct(baseline['val_balanced_accuracy'])} to {pct(weights['val_balanced_accuracy'])}. Explain the precision/recall and aggregate-accuracy trade-off. Do not claim that balancing helped every metric.

**Dropout:** R8 changed validation macro-F1 by {summary['dropout_validation_macro_f1_change']:+.4f} relative to R0 and achieved {pct(dropout['val_accuracy'])} validation accuracy. Dropout removes hidden activations during training and is disabled at inference. Report the actual outcome even if it did not help. The teacher decides whether it qualifies as a technique beyond class coverage.

## Figures ready for your own slides

- [Class counts](../figures/Group8_Class_Counts.png): explain 85.22% in two dominant classes and 0.47% Cottonwood/Willow.
- [Validation comparison](../figures/Group8_Validation_Comparison.png): explain the fixed selection metric.
- [Selected-run loss curve](../figures/Group8_Best_Loss_Curve.png): explain early stopping, restored epoch and the curve shape.
- [Confusion matrices](../figures/Group8_Confusion_Matrices.png): rows are true labels; columns are predictions; the right diagonal gives recall.

The figures are grayscale and can be inserted into the group's presentation. Use the CSVs for editable tables instead of screenshots when possible.

## Five mistakes

Use [Group8_Five_Errors.csv](../artifacts/Group8_Five_Errors.csv). It contains original row IDs, true/predicted labels, original-unit features, wilderness and soil indicators. We selected the lowest-row-ID error from each available true class until five, then filled remaining slots by row ID. Do not describe these as a random sample of all errors.

Observed values establish what the model got wrong. Similar terrain, class overlap and minority representation are hypotheses about why; no causal attribution was computed. A high softmax score can be wrong. It is not a calibrated confidence guarantee.

## Defensible client answer

The measured score supports considering source-like records for supervised screening with human verification. The weakest class recall was **{summary['worst_recall_class']} ({pct(summary['worst_recall'])})**. That prevents treating the overall accuracy as a guarantee for each class.

This is a random split of four Colorado wilderness areas. We did not test a Philippine forest, an unseen region, managed forest, a later period, calibration, or repeated seeds. The task predicts cover type from land attributes; it does not forecast fires or detect deforestation. Before operational use, validate on the intended region and review class-specific costs of errors.

## Group review before submission

1. Add names and roles where your instructor requires them. No names or contribution claims were invented.
2. Read and explain the notebook, including the scaler, class-weight formula, selection rule and test guard. Every member should be able to explain a cell outside their lead role.
3. Read the five-page [PDF report](../output/pdf/Group8_Report.pdf), check its claims against the notebook, and follow the instructor's AI-use rules. The report discloses research, coding, execution, analysis and drafting assistance.
4. Build and rehearse your own 8-12-slide presentation. No PowerPoint was produced by this workflow.
5. Complete private peer evaluations using the teacher's form. A blank aid is in [templates](templates/Group8_Peer_Evaluation_Template.md); no scores were assigned.

## Quick Q&A answers

- **Why only ten scaled columns?** The other 44 already represent binary wilderness/soil membership.
- **Why labels 0-6?** Sparse categorical cross-entropy expects class indices corresponding to seven output positions.
- **Why use validation repeatedly but test once?** Validation selects settings and stopping points; the held-out test supplies a final assessment after selection.
- **Why did the highest accuracy not automatically win?** We declared macro-F1 first because the dataset is imbalanced; use the actual table to explain any difference.
- **Did weights or dropout help?** Quote their measured changes and the objective, not a general promise about either technique.
- **Can this identify Philippine trees?** This study provides no evidence for that target population.

## Evidence location

`artifacts/study_manifest.json` freezes data/split/source identities and settings. `artifacts/runs/` has each history, model and validation class report. `artifacts/selection.json` records the pre-test winner. `artifacts/final_test_metrics.json` and saved probabilities/predictions record the final assessment. `artifacts/verification.json` contains the evidence-check result once verification completes.
"""
(ROOT / "docs" / "09_results-and-reporting-guide.md").write_text(text, encoding="utf-8")
record = ROOT / "docs" / "08_execution-record.md"
existing = record.read_text(encoding="utf-8")
if "## Completed assessed study" not in existing:
    record.write_text(existing + f"\n## Completed assessed study\n\nAll nine runs completed. Validation selected {selected['run_id']}; final test accuracy {pct(final['accuracy'])}, macro-F1 {final['macro_f1']:.4f}, balanced accuracy {pct(final['balanced_accuracy'])}. The final test phase finished {final['finished']} and records one evaluate call. The exact logs, errors and interpretation are in `09_results-and-reporting-guide.md`. Training was performed by the AI-assisted workflow, with member review and private evaluations left to the group.\n", encoding="utf-8")
print("Wrote measured reporting guide and execution record")
