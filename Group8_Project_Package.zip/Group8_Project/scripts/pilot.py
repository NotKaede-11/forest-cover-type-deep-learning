"""Check the existing runtime and full-data throughput; never score the test set."""
import os
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '2')
os.environ.setdefault('OMP_NUM_THREADS', '2')
import gc
import json
import time
from pathlib import Path
import numpy as np
import tensorflow as tf
from sklearn.datasets import fetch_covtype
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[1]
(ROOT / 'artifacts').mkdir(exist_ok=True)
tf.config.threading.set_intra_op_parallelism_threads(2)
tf.config.threading.set_inter_op_parallelism_threads(1)
tf.keras.utils.set_random_seed(42)
tf.config.experimental.enable_op_determinism()
start = time.perf_counter()
data = fetch_covtype(data_home=str(ROOT / 'data'))
x = data.data.astype('float32')
y = (data.target - 1).astype('int32')
del data
gc.collect()
ids = np.arange(len(y))
train_ids, reserved_ids = train_test_split(ids, test_size=0.2, stratify=y, random_state=42)
val_ids, test_ids = train_test_split(reserved_ids, test_size=0.5, stratify=y[reserved_ids], random_state=43)
scaler = StandardScaler().fit(x[train_ids, :10])
x[:, :10] = scaler.transform(x[:, :10])
opts = tf.data.Options()
opts.threading.private_threadpool_size = 2
opts.threading.max_intra_op_parallelism = 1
train = tf.data.Dataset.from_tensor_slices((x[train_ids], y[train_ids])).shuffle(len(train_ids), seed=42).batch(100).with_options(opts).prefetch(1)
val = tf.data.Dataset.from_tensor_slices((x[val_ids], y[val_ids])).batch(1024).with_options(opts).prefetch(1)
model = tf.keras.Sequential([tf.keras.Input((54,)), tf.keras.layers.Dense(50, activation='relu'), tf.keras.layers.Dense(50, activation='relu'), tf.keras.layers.Dense(7, activation='softmax')])
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'], steps_per_execution=32)
times = []
class Clock(tf.keras.callbacks.Callback):
    def on_epoch_begin(self, epoch, logs=None):
        self.start = time.perf_counter()
    def on_epoch_end(self, epoch, logs=None):
        times.append(time.perf_counter() - self.start)
        print('PILOT epoch', epoch + 1, 'seconds', round(times[-1], 3), flush=True)
model.fit(train, validation_data=val, epochs=2, callbacks=[Clock()], verbose=0)
result = {'purpose': 'runtime pilot only; excluded from scored experiment family', 'tensorflow': tf.__version__, 'gpu_devices': [str(d) for d in tf.config.list_physical_devices('GPU')], 'rows': len(y), 'train_rows': len(train_ids), 'validation_rows': len(val_ids), 'test_rows_reserved_not_evaluated': len(test_ids), 'epoch_seconds': times, 'total_seconds': time.perf_counter() - start, 'test_accessed': False}
(ROOT / 'artifacts' / 'pilot.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2), flush=True)
