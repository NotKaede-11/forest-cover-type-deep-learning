# Group 8 - Forest Cover Type

This folder contains the executed deep-learning study, its supporting evidence and the Group 8 presentation.

## Main files

| File/folder | Purpose |
| --- | --- |
| `Group8_Notebook.ipynb` | Self-contained notebook with code, explanations, plots and executed outputs |
| `output/pdf/Group8_Academic_Report.pdf` | Five-page grayscale case study with APA 7 references, numbered figures and tables, and all four members listed |
| `output/docx/Group8_Academic_Report.docx` | Editable Word copy of the five-page case study |
| `output/pptx/Group8_Case_Study.pptx` | Editable 12-slide PowerPoint with speaker notes, suggested timings and credited Colorado photographs |
| `output/docx/Group8_PPT_Content_Pack.docx` | Short copy for 12 slides, embedded study visuals, APA 7 references and suggested timing |
| `output/docx/Group8_Presentation_Review_and_QA.docx` | Review guide with 41 answered questions, notebook pointers and a rehearsal plan |
| `Group8_Study.py` | Readable notebook source; all its code appears in the notebook |
| `artifacts/Group8_Experiment_Log.csv` | Actual nine-run experiment table |
| `artifacts/Group8_Selected_Model.keras` | Validation-selected model |
| `artifacts/final_test_metrics.json` | Saved final evaluation; one test evaluate call |
| `artifacts/Group8_Test_Predictions.csv` | Saved row-level predictions for analysis |
| `figures/` | Grayscale figures for your presentation |
| `docs/09_results-and-reporting-guide.md` | Measured results and points to explain in your own presentation |
| `docs/templates/Group8_Peer_Evaluation_Template.md` | Blank private-evaluation aid; use the teacher's form if supplied |
| `docs/README.md` | Initial review and primary-source research index |
| `output/Group8_Project_Package.zip` | Portable copy with notebook, report, evidence, cached public data and source; excludes local environments |

The report's AI-use statement records the assistance that occurred. Members should review the work, understand the code, confirm speaking assignments and complete their private peer evaluations.

The PowerPoint speaker notes follow the final slide order and suggest a ten-minute talk with four speakers. Use the Word review guide for practice questions. The earlier content pack is a planning aid and has a different slide order. The presentation and revised report use the saved study results.

## Open the notebook

The project `.venv` reuses the existing Anaconda `py3-TF2` installation and adds missing packages locally. It has TensorFlow 2.21, Python 3.12 and CPU training. Your base Anaconda also has the Jupyter interface.

From a PowerShell terminal in this folder, register a kernel inside the project and open the existing Jupyter interface:

```powershell
.\.venv\Scripts\python.exe -m ipykernel install --prefix .jupyter --name group8 --display-name "Python 3 (Group 8)"
$env:JUPYTER_PATH = Join-Path (Get-Location) '.jupyter\share\jupyter'
& "$env:USERPROFILE\anaconda3\python.exe" -m notebook Group8_Notebook.ipynb
```

Select **Python 3 (Group 8)**. In an editor that can select an interpreter directly, choose `.venv\Scripts\python.exe` instead. Use **Restart Kernel and Run All** for an ordered rerun. Verified completed training runs load from their artifacts; the final-test section loads the saved assessment and does not score the test set again.

## Check or reproduce

Check the submitted evidence without training or test inference:

```powershell
.\.venv\Scripts\python.exe scripts\check_submission.py
```

Build and execute a separate reproduction notebook while preserving the main notebook:

```powershell
.\.venv\Scripts\python.exe scripts\build_notebook.py --execute --output Group8_Reproduction.ipynb
```

This uses the same local Jupyter kernel mechanism as the original execution. The saved signatures must match source, data, split, configuration and versions. A mismatch stops reuse. Do not delete the final-test marker or results to get around a mismatch. Changes after seeing test outcomes require a separately declared study and evaluation policy.

Regenerate the report from saved results:

```powershell
.\.venv\Scripts\python.exe scripts\make_report.py
```

Report generation reads CSV/JSON/image evidence and makes no model or test calls. Source edits or PDF changes should receive the same content and visual review before submission.

## Move to another computer

Use Python 3.12 and install `requirements.txt` in a new environment. The `.venv` and `.jupyter` directories are machine-specific; do not copy them as a portable environment. `requirements-lock.txt` records the original environment's complete installed package list. Exact hardware/software changes can change a newly trained model's numbers.

The cached public dataset in `data/` supports offline loading; `fetch_covtype` downloads it again when the cache is absent. Save the supplied artifacts alongside the notebook for evidence review. Run the notebook from this project folder. The original assignment brief is retained as `Group8_Finals_Project.pdf`.

## Study boundary

The study uses the full dataset and one fixed stratified split. Nine runs compare the baseline with one changed factor per variant. Validation macro-F1 selects the winner. Results establish performance on this source-data split, with no repeated-seed, new-region, temporal or calibration study. The report describes those limits.
