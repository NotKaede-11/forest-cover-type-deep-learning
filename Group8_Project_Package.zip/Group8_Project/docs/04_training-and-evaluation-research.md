# Training and evaluation research

Research date: **6 November 2026 (Asia/Manila)**. Sources below were read through BrowserOS Neo. This note preserves the initial implementation research, before training. The later [execution record](08_execution-record.md) and [measured results](09_results-and-reporting-guide.md) document what was subsequently run.

The assignment is the authority for course requirements. The linked official documentation establishes library behavior. Recommendations marked **Project choice** are proposed decisions, not requirements from those sources.

## 1. A practical runtime

TensorFlow's installation guide states that native Windows has no GPU support after TensorFlow 2.10. Modern NVIDIA GPU training on Windows therefore requires another supported route, such as WSL2, rather than simply installing a current native Windows package. CPU training remains a valid route. [TensorFlow installation](https://www.tensorflow.org/install/pip)

The same installation page currently contains an older general Python 3.9-3.12 requirement list alongside a more specific warning that TensorFlow 2.21 no longer supports Python 3.9 and lists Python 3.10-3.13 examples/wheels. Treat compatibility as version-specific; do not copy the broad list without checking the chosen release. **Project choice:** use an isolated Python 3.11 or 3.12 environment, first verify a working TensorFlow import and a tiny fit, then record exact package versions. Use CPU first if it meets the group's actual turnaround needs. If the group already has an available notebook GPU runtime, it can be considered without assuming availability, duration, or a particular speedup. No environment changes were performed during this review. [TensorFlow installation](https://www.tensorflow.org/install/pip)

Record Python, TensorFlow, Keras, NumPy, pandas, scikit-learn, operating system, CPU/GPU device, seeds, and elapsed time with the experiment evidence. A screenshot of an accelerator selector alone does not establish that training used it.

## 2. Keep preprocessing separate from model fitting

`StandardScaler` computes one mean and standard deviation per feature from the data passed to `fit`, then reuses those statistics in `transform`. The official leakage guidance says preprocessing must be learned from the training subset, never from the test set. [StandardScaler](https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.StandardScaler.html), [Common pitfalls: leakage](https://scikit-learn.org/stable/common_pitfalls.html#data-leakage)

**Project choice:** follow this order:

1. Check the raw schema and preserve original row IDs.
2. Freeze disjoint training, validation, and test row indices.
3. Fit the scaler on training columns 0-9 only.
4. Transform those ten columns in all three partitions with that same fitted scaler.
5. Preserve columns 10-53 as the original 0/1 indicators, following the assignment.
6. Compute any balancing weights using training labels only.

Do not fit three independent scalers, and do not standardize the entire matrix before splitting. Keep the training-fitted scaler with the selected model for reproducible inference.

`train_test_split` supports reproducible shuffled splits through an integer `random_state` and class-proportion stratification through `stratify`. **Project choice:** for approximately 80/10/10, hold out 20% using stratification, then split that holdout 50/50 with stratification again. Record actual integer row counts rather than assuming the fractions yield exact integers. Save indices so every run uses the same records. Stratification addresses class proportions; it does not itself address spatial dependence or guarantee geographic generalization. [train_test_split](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html)

## 3. Baseline contract

The assignment specifies two 50-unit ReLU hidden layers, Adam, seven softmax outputs, sparse categorical cross-entropy, and early stopping with patience 2. Its experiment template uses batch size 100. Preserve this baseline so subsequent comparisons have a clear reference.

| Item | Proposed explicit baseline setting | Reason |
| --- | --- | --- |
| Input | 54 features in the documented order | Matches the assignment's dataset |
| Hidden layers | 50 ReLU, then 50 ReLU | Required starting architecture |
| Output | Seven softmax probabilities | One mutually exclusive cover class per row |
| Labels | Integer IDs 0-6 | Original IDs 1-7 are shifted once |
| Loss | Sparse categorical cross-entropy, `from_logits=False` | Softmax already returns probabilities |
| Optimizer | Adam with explicit learning rate 0.001 | Avoids an undocumented implicit default |
| Batch size | 100 | Matches the baseline table in the brief |
| Epoch limit | Declare one shared cap before experiments | A stopping limit, not a promised training duration |
| Early stopping | `monitor='val_loss'`, `mode='min'`, `patience=2`, `restore_best_weights=True` | Preserves the checkpoint selected by validation loss |
| Validation | Explicit frozen `(X_val, y_val)` | Same validation examples in every run |

Sparse categorical cross-entropy expects integer target labels and one predicted probability per class, whereas categorical cross-entropy expects one-hot targets. Keep the target vector sparse; the existing one-hot **input columns** do not require one-hot **labels**. Pairing softmax with `from_logits=True` is a mismatch. [Keras sparse categorical cross-entropy](https://keras.io/api/losses/probabilistic_losses/#sparsecategoricalcrossentropy-class)

Adam's documented default learning rate is 0.001. Write it explicitly and change it in only its designated experiment. [Keras Adam](https://keras.io/api/optimizers/adam/)

`EarlyStopping` defaults to `restore_best_weights=False`, so requesting restoration is essential. Patience counts epochs without qualifying improvement, not the total number of training epochs. [Keras EarlyStopping](https://keras.io/api/callbacks/early_stopping/)

Keras's `validation_split` takes the final fraction of supplied arrays before shuffling. **Project choice:** explicit stratified validation data is easier to audit here. `History.history` records values for successive epochs; it does not automatically rewrite the final history entry after best weights are restored. [Keras training APIs](https://keras.io/api/models/model_training_apis/)

## 4. Address imbalance without hiding the tradeoff

Scikit-learn's balanced class-weight formula is:

`weight[class] = number_of_training_rows / (7 * training_count[class])`

Compute it from `y_train`, then map each integer class ID to its weight. Keras's `class_weight` changes loss weighting during training. Ordinary metrics passed through `metrics`, such as accuracy, remain unweighted; `weighted_metrics` is a separate mechanism. Validation data stays at its natural class distribution unless explicit validation sample weights are supplied. [compute_class_weight](https://scikit-learn.org/stable/modules/generated/sklearn.utils.class_weight.compute_class_weight.html), [Keras training APIs](https://keras.io/api/models/model_training_apis/)

**Project choice:** preserve all training rows. The cleanest evidence is the required unweighted baseline and controlled hyperparameter runs, plus an additional one-factor class-weight comparison. If the group instead fixes weighting for the complete required experiment family, document that policy and do not silently change it between runs. Neither policy is a demonstrated improvement until validation results exist. Avoid balancing validation or test to manufacture an easier or different evaluation distribution.

An important consequence: a weighted training loss and an ordinary validation loss measure different aggregate objectives. Their numerical gap alone cannot establish overfitting. Compare checkpoint performance on training and validation under matching ordinary inference metrics, and explain weighting in the loss-chart caption.

## 5. Metrics that answer the assignment

| Metric | Meaning | What to watch |
| --- | --- | --- |
| Overall accuracy | Fraction of all examples predicted correctly | Common classes dominate it |
| Per-class recall | Correct predictions for a true class divided by all examples of that true class | Best direct interpretation of the brief's "accuracy for each class" |
| Per-class precision | Correct predictions for a predicted class divided by all predictions of that class | Whether alerts for that class are reliable |
| Macro F1 | Unweighted mean of the seven class F1 scores | Gives each class equal influence |
| Balanced accuracy | Mean of the seven class recall scores | Makes rare-class failures visible |
| Support | Actual number of evaluated examples in each class | Small supports make estimates less stable |

Balanced accuracy is the macro average of per-class recall. A classification report provides precision, recall, F1, and support; its macro average weights classes equally, while its weighted average weights by class support. **Project choice:** report ordinary accuracy, macro F1, balanced accuracy, and a seven-row class table. Label recall clearly instead of an ambiguous seven-class one-vs-rest "accuracy" that can look high simply because negatives are numerous. [scikit-learn model evaluation](https://scikit-learn.org/stable/modules/model_evaluation.html#balanced-accuracy-score), [classification_report](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.classification_report.html)

A confusion matrix uses true classes as rows and predictions as columns. **Project choice:** display a count matrix and a matrix normalized by true row, with fixed class order 0-6 and readable names. The normalized diagonal shows per-class recall. [confusion_matrix](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html)

## 6. Choose and log checkpoints consistently

**Project choice:** declare the selection rule before training. The companion execution plan proposes highest validation macro-F1 at each run's restored minimum-validation-loss checkpoint, with exact ties broken by validation accuracy, lower validation loss, fewer parameters, then lower run ID. This prioritizes all seven classes while retaining the brief's required accuracy/loss evidence. If the teacher requires accuracy-first selection, record that policy before experiments and discuss the rare-class tradeoff. Neither ranking is mandated by the API documentation. Do not switch rules after seeing the test set.

For every run, preserve:

- Full configuration and the single changed factor relative to its named reference run.
- Split IDs, sample scope, seed, data identity, and environment identity.
- Total epochs completed and best epoch selected by the stopping monitor.
- Training/validation loss history and training/validation accuracy history.
- Validation loss and validation accuracy from the **same selected checkpoint**.
- Validation macro F1 and per-class recall from that selected checkpoint.
- Runtime, model parameter count, and the model/checkpoint file path.

Do not combine the lowest loss from one epoch and highest accuracy from a different epoch and present them as one model. Do not label the last history entry as restored-checkpoint performance. It is acceptable to evaluate validation repeatedly during selection; the protected set is the test set. Early stopping behavior and the epoch history format support this distinction. [Keras EarlyStopping](https://keras.io/api/callbacks/early_stopping/), [Keras training APIs](https://keras.io/api/models/model_training_apis/)

## 7. One final test block

The assignment explicitly requires one `model.evaluate` on test data after model selection. **Project choice:** freeze the selected checkpoint, preprocessing, label map, run ID, and final configuration before this block. Do not automatically retrain the chosen architecture on train+validation, since that would create a different model with no untouched validation set for stopping.

Then:

1. Run `evaluate` once on the full test partition and save the returned loss/accuracy immediately.
2. Obtain and save predictions from that same fixed model for the same test rows.
3. Derive the class table, confusion matrices, macro F1, balanced accuracy, and five error examples from those saved predictions.
4. Write conclusions; do not alter the model based on these results.

`evaluate` returns losses/metrics in test mode, while `predict` produces model outputs. Producing predictions for the brief's required mistakes analysis is compatible with one final assessment; it must not turn into another model-selection round. Recomputing a chart from saved predictions does not require another model test. Accidental notebook reruns should load saved final results rather than re-execute the protected evaluation automatically. [Keras training APIs](https://keras.io/api/models/model_training_apis/), [scikit-learn leakage guidance](https://scikit-learn.org/stable/common_pitfalls.html#data-leakage)

For each wrong example, retain original row ID, true class, predicted class, selected original-unit attributes, and optionally maximum softmax probability. Suggest explanations as hypotheses supported by actual observed similarities or confusion patterns. Softmax confidence is not a guarantee of correctness, and these observational features cannot establish a causal reason for a particular error.

## 8. Reproducibility and interpretation

TensorFlow's seed utility sets Python, NumPy, and TensorFlow seeds. Operation determinism can improve repeatability but may slow computation. Guarantees require the same hardware and software environment; cross-version identity is not guaranteed. NumPy `default_rng` needs its own explicit seed. [TensorFlow determinism](https://www.tensorflow.org/api_docs/python/tf/config/experimental/enable_op_determinism)

**Project choice:** reset the declared seed before constructing each fresh model, keep partitions and preprocessing fixed, and record versions. Use fresh model and optimizer state for independent runs. If resources permit, repeat only the leading validation candidates with additional seeds before opening the test set; label repeats separately from one-factor experiments. A single-seed improvement is evidence from that run, not proof of universal superiority.

Training-history accuracy is accumulated while weights are changing. For the final train/validation/test comparison, prefer ordinary inference-mode accuracy for the same frozen checkpoint on each partition. Weighted objectives and dropout make unqualified comparisons of raw training loss versus validation loss especially misleading.

## 9. Optional bonus techniques

Dropout randomly removes a fraction of activations during training and is disabled during ordinary inference. **Project choice:** an additional dropout-only experiment can test regularization; compare to a clearly named reference and retain it only if validation evidence supports the tradeoff. It may reduce training accuracy without harming validation performance, so explain its behavior instead of equating lower training accuracy with failure. [Keras Dropout](https://keras.io/api/layers/regularization_layers/dropout/)

`ReduceLROnPlateau` reduces the learning rate after its monitored value stops improving. **Project choice:** if testing this bonus, change only the scheduler relative to a fixed reference; use an early-stopping patience long enough to permit the scheduled reduction to have an effect, keeping that same patience in the reference run. Otherwise a patience-2 stop may occur before a patience-5 schedule ever acts. This is a design inference from the two callbacks, not measured evidence that a scheduler helps Covertype. [Keras ReduceLROnPlateau](https://keras.io/api/callbacks/reduce_lr_on_plateau/), [Keras EarlyStopping](https://keras.io/api/callbacks/early_stopping/)

## 10. What remains unverified

No package installation, data loading, model fitting, hyperparameter result, hardware speed, GPU availability, accuracy, class recall, or final-test claim was verified by this research. Library documentation supplies behavior, not project results. The group must record measured evidence before replacing any planned entry with a result. Exact class counts, source provenance, data quality, spatial limitations, and assignment requirements belong to the companion dataset and requirements notes.
