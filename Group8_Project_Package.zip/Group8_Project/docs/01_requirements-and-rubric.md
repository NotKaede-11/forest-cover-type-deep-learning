# Assignment requirements and rubric

Source: [Group8_Finals_Project.pdf](../Group8_Finals_Project.pdf), all six pages. Page references below refer to the original PDF. Review date: 6 November 2026.

## Required outputs

| Output | Binding requirement | Suggested name |
| --- | --- | --- |
| Jupyter notebook | One notebook, task headings, all loading-to-test code, executed top to bottom with visible outputs | `Group8_Notebook.ipynb` |
| Report | PDF, 3-5 pages; dataset, preprocessing, model, experiment log, final results, business answer; labeled figures | `Group8_Report.pdf` |
| Presentation | 8-12 slides; all four members speak; 10-minute presentation plus 5-minute Q&A | `Group8_Slides.pptx` if accepted by teacher |
| Peer evaluation | Each member privately rates the other three on contribution, reliability, teamwork, and whole-project understanding | Use teacher's required private channel/form |

The brief requires the group number in every submitted filename. It does not specify the slide file format, upload platform, peer-evaluation form, or final calendar deadline. Do not invent them. [PDF pp. 3-5]

## Requirement-to-evidence checklist

| Task | Evidence that must exist | Owner leads |
| --- | --- | --- |
| Explore | Shape, number of classes, first rows, feature meanings, class counts and imbalance explanation | Data |
| Preprocess | Missing-value and category checks; standardize first 10 columns only; explain imbalance handling; shuffled, disjoint train/validation/test split | Data |
| Baseline | Two hidden layers of 50 ReLU units, seven softmax outputs, Adam, sparse categorical cross-entropy, validation data, early stopping patience 2 | Model |
| Experiments | Baseline plus at least six controlled changes is the safe reading; every comparison changes one factor; log change, epochs, validation loss and accuracy | Experiment |
| Learning curves | Training versus validation loss for the best run, with readable axes and legend | Experiment |
| Final selection | Evidence that validation, not test performance, determined the winner | Model + Experiment |
| Final test | One final `model.evaluate` on test data, with honest test accuracy | Model |
| Interpretation | Comparable training/validation/test accuracy, discussion of overfitting, per-class performance, five or more wrong test examples and plausible explanations | All |
| Client answer | Would we trust the model, for what use, and what could go wrong? | Report + All |
| Reproducibility | Notebook runs in order without hidden-state errors; visible outputs and documented environment | All |
| Academic integrity | Original group work, disclosed AI help, every member able to explain every line | All |

Dataset-specific notes on PDF p. 2 take precedence over generic preprocessing wording on p. 3: the 44 indicator columns are already encoded. Do not encode them again. Missing-value handling is conditional on finding missing values, not an instruction to introduce imputation unnecessarily.

## Points and practical priorities

| Criterion | Points | Full-credit target | Main avoidable failure |
| --- | ---: | --- | --- |
| Exploration/preprocessing | 20 | Counts, justified imbalance treatment, clean three-way split | Fitting preprocessing on all data or leaking test information |
| Model/training | 15 | Correct layers, loss, output size, validation, early stopping | Wrong target encoding/loss or no validation |
| Experiments/tuning | 20 | Six or more controlled experiments, clear log and loss chart | Multiple settings changed together or missing runs |
| Final test | 10 | Validation-selected model, one final test, honest result | Repeated test-driven selection |
| Results/business answer | 15 | Overfitting check, errors, useful answer with limits | Only reporting one accuracy number |
| Report | 10 | Complete, clear, 3-5 pages with labeled figures | Dumping notebook screenshots without explanation |
| Presentation/Q&A | 10 | Everyone speaks and understands every part | One expert doing all explanation |
| Total | 100 | All core evidence complete | Bonus pursued while core evidence is missing |

Up to five bonus points are available for a technique not taught in class, such as dropout or a learning-rate schedule, **and an explanation of what it does and whether it helped**. Improvement is not guaranteed. Ask whether a proposed technique was already taught before claiming bonus eligibility. [PDF p. 5]

## Roles and individual scoring

The four lead roles are Data, Model, Experiment, and Report. A lead owns coordination and evidence for an area; this is not permission for the other members to skip its code. The teacher may ask any member any question or request a live cell execution. [PDF pp. 2, 4]

Private peer-rating effects are: average 4.0-5.0 earns 100% of the group score; 3.0-3.9 earns 90%; below 3.0 earns 75% after a teacher conversation. Each student privately rates the other three. These research notes do not assign names, contributions, or ratings. [PDF p. 5]

## Ambiguities and safe interpretations

| Brief detail | Interpretation for planning | Clarify before affected work |
| --- | --- | --- |
| Says “5-step plan,” then lists Steps 1-6 | Implement all six listed steps | No blocker |
| At least six experiments; seven-row table includes baseline | Plan baseline + six one-factor changes | Whether six including baseline would suffice is unnecessary to rely on |
| Generic “balance” instruction; dataset tips say explain the choice | Show imbalance, compare a training-only weighting policy, report trade-offs | Whether teacher insists on resampling rather than weights |
| Larger batches 500/1,000 suggested; baseline template says batch 100 | Keep batch 100 for baseline; vary batch alone in a planned experiment | No blocker |
| “Best validation results” with no ranking metric | Predeclare macro-F1 for imbalance; always log accuracy/loss | Teacher's preferred winner-selection metric |
| “Accuracy for each class” | Report recall for each true class with its support and a normalized confusion matrix; define the term | Any teacher-specific terminology |
| Test once plus five wrong test examples | One evaluation phase: one evaluate call, then predictions for fixed-model analysis | Whether teacher counts predict as part of the same final-test phase |
| Notebook must run top to bottom; test must run once | Complete debugging on train/validation, then one final end-to-end execution and retain outputs | Policy for examiner reproduction after the final test |
| AI may help debug; disclose how used | Record this research help accurately, and obtain policy clarity before broader AI-authored assessed work | Whether research/planning/code generation beyond debugging is allowed |
| TensorFlow Datasets and scikit-learn both mentioned | Use the supplied `fetch_covtype` path; no need for a second data loader | Whether TFDS installation itself is required |

## Acceptance gate before submission

- [ ] All four named leads and actual deadline confirmed.
- [ ] All six task headings and required outputs present.
- [ ] Baseline and six controlled variants have real saved logs.
- [ ] Scaling, split and class-label invariants verified.
- [ ] Model choice is documented before the final test.
- [ ] Per-class results and at least five wrong examples included.
- [ ] Report is 3-5 pages; slides are 8-12; talk rehearsed to 10 minutes.
- [ ] Every member can explain a randomly selected cell.
- [ ] AI-use statement matches what happened and teacher policy.
- [ ] Private peer evaluations are submitted by each member.
