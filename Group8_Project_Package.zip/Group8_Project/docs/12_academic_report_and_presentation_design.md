# Academic design for the Group 8 report and presentation

The revised report uses the assignment’s five-page limit. The final deck uses 12 slides with ten minutes of suggested speaking time in the notes. The earlier Word content pack follows a different slide order.

## Photographs used in the deck

| Slide | Photograph | Credit and license |
| --- | --- | --- |
| 1 | [Rawah Wilderness](https://commons.wikimedia.org/wiki/File:Rawah_Wilderness.jpg) | refractor, [CC BY 2.0](https://creativecommons.org/licenses/by/2.0/). The slide crops the original. |
| 2 | [Medicine Bow Mountains at Jackson–Larimer County Border](https://commons.wikimedia.org/wiki/File:Medicine_Bow_Mountains_at_Jackson-Larimer_County_Border_in_Colorado_(2520238260).jpg) | Ken Lund, [CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0/). |
| 11 | [Cache la Poudre River in Poudre Canyon](https://commons.wikimedia.org/wiki/File:Cache_la_Poudre_River_in_Poudre_Canyon_high_walls.JPG) | Wusel007, [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/). |

The photographs show Colorado landscapes. They are separate from the tabular model inputs.

Reviewed 9 November 2026. The course brief calls for a 3–5 page PDF and 8–12 slides, with a 10-minute talk, 5 minutes for questions, and all four members speaking. The slide examples below use the completed experiment's saved results. [Course brief](../Group8_Finals_Project.pdf) · [Results and reporting guide](09_results-and-reporting-guide.md)

## Written report

Use APA 7 figure, table, and citation conventions within the compact course format. APA's student-paper guide gives instructors' instructions priority. A full APA student manuscript also has a title page, one-inch margins, and double-spaced body text. The existing report uses its five pages for the case study and references, so describe its format as a course report with APA 7 citations and display conventions. [APA Student Paper Setup Guide, pp. 1–2 and 19](https://apastyle.apa.org/instructional-aids/student-paper-setup-guide.pdf) · [Existing reference update](11_APA7-reference-update.md)

| Page | Main job | Evidence and layout |
| --- | --- | --- |
| 1 | State the question, dataset, imbalance, and split | Short title and team information, data context, a compact class-frequency figure, and the split counts |
| 2 | Document preprocessing, baseline, and controlled experiments | Brief method prose followed by the nine-run experiment table, with the selected run identified |
| 3 | Explain checkpoint selection and final performance | Selected-run loss curves, the frozen checkpoint's train/validation/test scores, and per-class evidence |
| 4 | Discuss errors, applicability, and limitations | Five selected errors with their selection method, a bounded client recommendation, and the AI-use disclosure |
| 5 | Document sources | Alphabetical APA 7 references with live links and hanging indents |

This is a proposed page allocation. Figure and table placement should follow the first mention and actual pagination. Use a consistent, left-aligned reading column and one heading hierarchy. Keep chart labels at a readable final size after scaling and move supporting detail into the notebook if space is tight. [APA figure setup](https://apastyle.apa.org/style-grammar-guidelines/tables-figures/figures) · [MIT EECS Communication Lab figure design](https://mitcommlab.mit.edu/eecs/commkit/figure-design/)

### Figures and tables

- Number figures and tables in separate sequences according to their first mention in the report. Use a bold number above a short italic title in title case. Put the chart or table beneath the title, followed by an explanatory note if needed. Refer to each display in the body before it appears. Keep each number, title, visual, and note together in the PDF. [APA figure setup](https://apastyle.apa.org/style-grammar-guidelines/tables-figures/figures) · [APA table setup](https://apastyle.apa.org/style-grammar-guidelines/tables-figures/tables)
- Use clear headings for every table column. Set comparable results next to each other and show matching units and decimal precision. Use horizontal rules at the top, below the headings, and at the bottom. Whitespace and alignment separate columns. In the experiment table, “Epochs run” and “Restored epoch” represent different quantities. State the macro-F1 selection rule in a note. [APA table setup](https://apastyle.apa.org/style-grammar-guidelines/tables-figures/tables) · [Selection record](../artifacts/selection.json)
- Use 8–14 pt sans-serif text inside report figures at their final displayed size, with axis labels, units, and a readable key when needed. For the loss curve, use solid and dashed lines, label epoch and cross-entropy, and mark restored epoch 11. For a normalized confusion matrix, label the row and column roles and state the row denominator. Add contrast and direct labels so readers can follow the figure in grayscale. [APA figure setup](https://apastyle.apa.org/style-grammar-guidelines/tables-figures/figures) · [APA accessible figure colors](https://apastyle.apa.org/style-grammar-guidelines/tables-figures/colors)

Example report display:

> **Figure 2**  
> *Training and Validation Loss for Run R1*  
> [Loss curves with a marker at epoch 11]  
> *Note.* The run completed 13 epochs and restored the weights from epoch 11, which had the lowest validation loss.

The display title names the evidence. The surrounding prose explains why the checkpoint was retained, then distinguishes the early-stopping criterion from the model-selection criterion. Use a source credit when reproducing or adapting an external display. For original charts generated from Group 8's analysis, cite the underlying dataset or evidence where it helps readers trace the result. [APA figure setup](https://apastyle.apa.org/style-grammar-guidelines/tables-figures/figures) · [Run R1 metrics](../artifacts/runs/R1/metrics.json)

## Oral presentation

Give each evidence slide a short sentence headline and one visual the speaker can explain. Put implementation detail, secondary metrics, and anticipated questions in speaker notes or in the final backup slide. In Garner and Alley's experiment with 110 engineering students, slides that applied several multimedia principles together produced better comprehension and delayed recall in that setting. The study compared whole slide designs, so it cannot isolate the effect of changing a headline alone. [Garner and Alley, 2013](https://www.ijee.ie/articles/Vol29-6/23_ijee2791ns.pdf) · [MIT EECS Communication Lab slide guidance](https://mitcommlab.mit.edu/eecs/commkit/slideshow/)

The table illustrates how to adapt the same evidence to the report and to the live talk. The existing content pack has the speaker order and timing. [Presentation content pack](../output/docx/Group8_PPT_Content_Pack.docx)

| Evidence | Report treatment | Slide treatment |
| --- | --- | --- |
| Class imbalance | All seven counts and proportions with source context | **Two classes account for 85.22% of all records.** Use seven horizontal bars on a zero-based count axis. Emphasize the two largest bars and label the smallest count. |
| Preprocessing | Explain the shuffled stratified split, train-only scaling, and the unchanged binary inputs | **The scaler learned only from training rows.** Use three branches from the split and a common transform, with the training-only fit labeled. |
| Model | Document the baseline and selected architecture, optimizer, loss, batch size, and stopping setup | **Widening both hidden layers raised validation macro-F1.** Use two simple layer sequences for the baseline and R1, with 0.7827 and 0.8272 beside them. |
| Selection | Show every assessed run with restored checkpoint metrics and the declared selection rule | **R1 led on the metric we chose before testing.** Show validation macro-F1 for all runs and highlight R1. Use the notes to explain that R3 led on accuracy and R6 was close on macro-F1. |
| Early stopping | Plot the full selected run's loss history and describe the best checkpoint | **Training stopped after 13 epochs and restored epoch 11.** Plot both curves and label the marker directly. |
| Held-out performance | Give train, validation, and test accuracy plus macro-F1 and balanced accuracy with denominators | **The frozen model reached 88.75% test accuracy.** Place the three split accuracies together and label the test scope of 58,102 records. |
| Class-specific performance | Give all seven classes with recall, precision, F1, and support, with the matrix available as context | **Douglas-fir had the lowest test recall at 64.42%.** Use seven recall bars with names, a 0–100% axis, and the Douglas-fir denominator of 1,737. |
| Error analysis | Give all five case records, relevant feature values, and the selection method | **The errors show where field checks still matter.** Use two legible examples if the others remain in speaker notes or the report. Label observed values and proposed explanations separately. |
| Client decision | State the intended use, geographic scope, and evidence still needed | **Field teams could use the model to triage source-like records.** Pair the use with human verification and validation on the intended region. |

Use wide slides with dark text on a light background, one restrained emphasis color or shade, and consistent chart styles. Set slide text and chart labels at 18 pt or larger where possible and check them in slideshow mode at a realistic viewing distance. Add descriptive alt text to informative graphics and verify reading order in PowerPoint. W3C's contrast thresholds are useful design benchmarks for slide colors, with 4.5:1 for ordinary text and 3:1 for large text. Combine emphasis color with a label, a different line style, or another visible cue. [Microsoft PowerPoint accessibility guidance](https://support.microsoft.com/en-us/accessibility/powerpoint/make-your-powerpoint-presentations-accessible-to-people-with-disabilities) · [W3C WCAG 2.2, sections 1.4.1 and 1.4.3](https://www.w3.org/TR/WCAG22/#distinguishable)

## Checks before export

- Cross-check the PDF, slides, and speaker notes against the saved result files. Keep validation macro-F1, test macro-F1, and balanced accuracy labeled separately. [Experiment log](../artifacts/Group8_Experiment_Log.csv) · [Final test metrics](../artifacts/final_test_metrics.json)
- Read the exported PDF at page fit and inspect dense charts at 100%. Check label clipping, page breaks, decimal alignment, and the readability of figure notes. Check slide text, chart labels, and contrast in slideshow mode. [MIT EECS Communication Lab figure design](https://mitcommlab.mit.edu/eecs/commkit/figure-design/) · [Microsoft presentation guidance](https://support.microsoft.com/en-us/powerpoint/tips-for-creating-and-delivering-an-effective-presentation)
- Rehearse the speaker handoffs within 10 minutes. Ask each speaker to explain one method or result from another speaker's section before the group rehearses the five-minute Q&A. [Course brief](../Group8_Finals_Project.pdf) · [MIT EECS Communication Lab slide guidance](https://mitcommlab.mit.edu/eecs/commkit/slideshow/)

