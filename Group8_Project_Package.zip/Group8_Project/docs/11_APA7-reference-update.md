# APA 7 reference update

Updated 6 November 2026 at the user's request. This revision changes the PDF's references and in-text citations; the study, notebook, models and results remain the same.

- Replaced numeric citation labels with author-date citations.
- Alphabetized seven reference entries, with chronological order for Blackard's works and title-based n.d.-a/b/c suffixes for undated works by the same group author.
- Used initials, sentence-case titles with API/proper-name capitalization preserved, italicized standalone titles, dataset descriptions, and DOI/URL links.
- Used a separate References page, a bold centered heading, 12-point Times text, double spacing, and a 0.5-inch hanging indent.
- Used n.d. for undated documentation rather than assigning copyright years as publication dates. Retrieval dates identify the changing online API documentation.
- Verified the source name Jock A. Blackard and the codebook's stated December 7, 1999 update against the original covtype.info footer. The dataset entry retains the 1998 dataset year and DOI.
- Rearranged existing discussion to preserve the assignment's five-page limit and grayscale design. This is APA 7 citation/reference formatting, not a claim that the whole short project report follows the full APA student-paper template.

Formatting guidance checked through BrowserOS Neo:

- [Purdue OWL: Reference list basic rules](https://owl.purdue.edu/owl/research_and_citation/apa_style/apa_formatting_and_style_guide/reference_list_basic_rules.html)
- [Purdue OWL: Electronic sources](https://owl.purdue.edu/owl/research_and_citation/apa_style/apa_formatting_and_style_guide/reference_list_electronic_sources.html)
- [Purdue OWL: General format, APA 7](https://owl.purdue.edu/owl/research_and_citation/apa_style/apa_formatting_and_style_guide/general_format.html)
- [Original Covertype documentation](https://archive.ics.uci.edu/ml/machine-learning-databases/covtype/covtype.info)

APA's own example page required a security challenge. The update used the accessible university guidance above rather than interacting with that challenge.
