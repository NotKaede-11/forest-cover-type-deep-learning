# Proposed execution and experiment plan

Status: original plan, 6 November 2026. The authorized workflow has since executed this nine-run full-data design; actual results are in [09](09_results-and-reporting-guide.md) and the [execution record](08_execution-record.md). The plan below preserves the decisions made before training. The [brief](../Group8_Finals_Project.pdf) sets requirements; API evidence and caveats are in [04](04_training-and-evaluation-research.md).

## Notebook structure

Use one notebook, with the six task headings from the brief. A short setup section can precede them.

| Section | Cells and evidence |
| --- | --- |
| Setup | Group roles, question, AI disclosure, package/runtime versions, random seeds, explicit data path, frozen run plan |
| 1. Explore | Load, source description, shape, class map, first rows, compact dictionary, missingness/finite/binary checks, count plot |
| 2. Preprocess | Fixed optional sample, original row IDs, stratified split, partition counts, scaler fit on training only, untouched indicators, imbalance policy |
| 3. Baseline | Model summary, loss/optimizer explanation, early stopping, saved history and restored-checkpoint validation scores |
| 4. Experiments | Fresh models and callbacks, one-factor run configurations, complete log, validation comparison and best-run loss chart |
| 5. Final model/test | Freeze selection and artifacts, single test evaluation phase, saved metrics and predictions |
| 6. Explain | Comparable train/validation/test scores, confusion matrix, class report, five errors, business answer and limits |

Keep helper code small and named for the task, for example model construction and one training-run function. No service, web application, distributed training platform, or experiment-tracking server is required by the brief.

## Data contract before training

1. Load data and preserve row IDs; map labels 1-7 to 0-6 exactly once.
2. Decide whether the assessed study uses all rows or a fixed 100,000-row stratified sample. A preliminary sample must not be selected because it gives higher scores. Mark any pilot runs separately from assessed experiments.
3. Create one approximately 80/10/10 stratified split. One simple recipe is reserve 20% temporarily, then split that holdout equally into validation and test, with fixed seeds and stratification in both operations. Record actual rounded sizes.
4. Inspect class support and split-ID disjointness. Freeze split IDs before modeling; do not reroll splits for a better score.
5. Fit one StandardScaler on training columns 0-9. Apply that learned transform to training, validation, and test numeric columns. Leave columns 10-53 as 0/1. Save the scaler with the selected model.
6. Keep validation and test in their natural class proportions. Any weights or resampling use training rows only. Avoid resampling before splitting, because copies can cross partitions.
7. Use the same data, feature order, scaling policy, split IDs, and seed policy for every controlled run.

A 100,000-row study is explicitly permitted by the brief. It is a fallback for measured runtime constraints, not an excuse to change data size between experiment rows. If later moving from a sample study to a full-data study, declare a new study and rerun the comparable experiment set before the final test.

## Fixed baseline configuration

| Setting | Proposed value | Basis |
| --- | --- | --- |
| Inputs | 54 features | Dataset/brief |
| Hidden layers | 50 ReLU, 50 ReLU | Required taught starting model |
| Outputs | 7 softmax | Seven mutually exclusive target classes |
| Trainable parameters | 5,657 | Calculated: 55*50 + 51*50 + 51*7 |
| Optimizer | Adam, learning rate 0.001 | Explicit planning choice using normal Adam starting rate |
| Loss | Sparse categorical cross-entropy, probabilities rather than logits | Integer labels 0-6 and softmax output |
| Batch size | 100 | Brief's baseline table |
| Epoch limit | 50 | Planning choice; log runs reaching the cap |
| Early stopping | Monitor val_loss; patience 2; restore best weights | Patience required; restore is deliberate to retain best checkpoint |
| Class weights | None | Unweighted reference for separate imbalance comparison |
| Seeds | Fixed split and training seed policy, starting with 42 | Planning choice, not a guarantee across machines |

Rebuild and recompile the network from scratch for every run. Reset the seed policy and use fresh optimizer/callback state. Continuing training an old model would change the comparison. If a run reaches the epoch cap, report that rather than silently extending only that run. A common larger cap would define a separately documented round.

## Controlled experiment matrix

Every core variant compares to **R0**, not the previous row. Each changes one conceptual factor. The specific values below are hypotheses; they may help, hurt, or make no meaningful difference.

| Run | Reference | One changed factor | Setting | Question |
| --- | --- | --- | --- | --- |
| R0 | None | Baseline | 50-50 ReLU; batch 100; lr 0.001; patience 2 | What does the taught starting model achieve? |
| R1 | R0 | Width | 100-100 hidden units | Does greater capacity help? |
| R2 | R0 | Depth | 50-50-50 hidden units | Does another hidden layer help? |
| R3 | R0 | Hidden activation | tanh in both hidden layers | Is a different nonlinearity useful? |
| R4 | R0 | Batch size | 500 | What is the quality/runtime trade-off? |
| R5 | R0 | Learning rate | 0.0003 | Does a smaller optimization step help? |
| R6 | R0 | Early-stopping patience | 5 | Was baseline stopping too early? |
| R7 | R0 | Training class weights | Balanced weights from training labels only | Does reweighting improve minority performance? |
| R8, optional | R0 | Dropout regularization | Rate 0.2 after each hidden layer | Does dropout help enough to explain for the bonus? |

R0-R6 give seven total rows, covering baseline plus six changes. R7 is recommended because imbalance is central to this assignment. R8 is optional and only a bonus candidate if dropout was not already taught. Do not combine R1, R4, R5, and R7 and attribute any gain to one setting. A combined candidate may be a later explicitly labeled experiment with its own comparison, but it is unnecessary to satisfy the base plan.

Training weights for R7 are `n_train / (7 * count_train_for_class)`. Record the resulting seven weights. Never derive them from combined train/validation/test labels. Select using actual validation trade-offs; do not assume weights improve all classes or overall accuracy.

## Measurement and selection rules

Predeclare the selection metric before running experiments. **Proposed rule:** highest validation macro-F1 at the checkpoint restored by early stopping; exact ties use validation accuracy, then lower validation loss, then fewer parameters, then lower run ID. This keeps rare classes relevant while retaining the brief's required accuracy/loss log. If the teacher requires validation accuracy as primary, change and record the rule before experiments, not after seeing test results.

For each run save configuration, seed, data/split identity, parameter count, runtime, epochs actually run, selected checkpoint epoch, validation loss, validation accuracy, validation macro-F1, balanced accuracy, class recalls, history, and model artifact. Required columns can appear in the report; the fuller ledger supports them. The supplied [CSV](templates/experiment-log.csv) intentionally has blank result fields.

Important reporting details:

- Distinguish epochs executed from the selected epoch. Never combine maximum validation accuracy from one epoch with minimum loss from another and pretend they describe one model.
- Early stopping on val_loss and ranking runs by macro-F1 are different operations. Both are fixed policies; report the restored checkpoint's actual metrics.
- Class weighting changes training loss. A weighted train-loss versus unweighted validation-loss gap is not by itself proof of overfitting.
- For final train/validation/test comparison, compute train and validation accuracy on the same frozen checkpoint with inference behavior. Training-history accuracy was accumulated during optimization and may differ.
- Prefer a limited predeclared run set over endless validation searching. Optional repeated seeds for top candidates must use validation only and a declared budget; one-seed gains are not proof of statistical superiority.

## Final-test phase

Before test access, record the winning run, selection rule, exact saved model, preprocessing, class map, split IDs, package versions, timestamp, and reason for selection. Do not refit on train+validation in this base workflow: that would produce a different model from the one selected and complicate the single-test policy.

Run `model.evaluate` once on the frozen test partition. Obtain predictions from that same model for the required class report, confusion matrices, and wrong-example analysis. This is one final evaluation phase, not an opportunity to compare candidate models. Save predictions so chart edits and report writing do not trigger more test inference. If the teacher interprets “test once” more strictly, clarify the evaluate/predict reporting workflow before reaching this phase.

Report overall accuracy, macro-F1, balanced accuracy, per-class precision/recall/F1/support, and raw and row-normalized confusion matrices. Use a fixed 0-6 class ordering with human-readable names. Explain “per-class accuracy” as recall: correctly predicted members of a true class divided by all members of that true class.

Choose at least five wrong cases reproducibly: for example, first select the lowest-row-ID error from each available true class until five cases, then fill remaining slots by row ID. For each show true/predicted names, original units for selected features, wilderness/soil indicators, and model score if helpful. Label explanations as hypotheses; inputs alone do not prove why the network made that error. If fewer than five errors exist, report the count and ask the teacher how to satisfy the example requirement; never fabricate errors.

Once test results are visible, stop model selection. Poor results become an honest limitation and future-work discussion. A code or split defect discovered afterward invalidates the original evaluation claim; record the incident and obtain a new evaluation policy rather than quietly replacing the result.

## Notebook execution and artifact discipline

Debug loading, preprocessing, plotting, and run orchestration on training/validation first. Reserve the first complete end-to-end execution that reaches the sealed test section for finalization, then retain that notebook's outputs and artifacts. Make it understandable how an examiner can reproduce the frozen procedure without using the result to tune again. Clarify the instructor's rerun policy if needed.

Suggested future artifact layout (not created or populated by this review):

```text
Group8_Notebook.ipynb
artifacts/
  split_indices.npz
  experiment_log.csv
  runs/R0/... through R7/...
  selected_model.keras
  preprocessing_and_class_map...
  final_test_metrics.json
  final_test_predictions.csv
figures/
  class_counts.png
  validation_comparison.png
  best_loss_curve.png
  confusion_matrix.png
Group8_Report.pdf
Group8_Slides.pptx
```

Keep all submitted references portable and relative to the project folder. Record exact package versions after a successful preflight. No dependencies were installed and no training, dataset download, or final-test access occurred during this review.
