# Group workflow, report, and presentation

Prepared 6 November 2026. This is a proposed production plan based on the [brief](../Group8_Finals_Project.pdf), not a record of work already completed by members.

## Roles with shared understanding

| Lead | Concrete ownership | Evidence to hand over | Cross-review partner |
| --- | --- | --- | --- |
| Data | Source, class map, quality checks, sampling/splits, scaling | Class counts, split indices, dictionary, preprocessing explanation | Model Lead |
| Model | Baseline, compile/fit, callbacks, saved model | Model summary, training history, checkpoint identity | Experiment Lead |
| Experiment | Run matrix, controlled comparisons, ledger, validation selection | Complete logs, comparison plot, chosen-run justification | Data Lead |
| Report | Report/slides assembly, references, coherent client answer | Final text, figure captions, timing plan, disclosure | Everyone |

Leave member names unassigned until the group agrees. Do not infer this four-member group's roster from the user's earlier two-person projects in the vault.

Every member should implement or materially revise cells, review another section, explain the full notebook, and rehearse answers outside their lead area. Keep a small factual contribution record: date, member, artifact/cell, contribution, reviewer. It supports coordination; it must not become fabricated contribution evidence or public peer ratings. Private evaluations remain each student's responsibility.

## Three-week checkpoints from the brief

These are relative milestones, not calendar commitments. The assignment's actual submission date is blank.

| Stage | Work | Exit evidence |
| --- | --- | --- |
| Week 1 | Assign roles; obtain class notebooks; verify runtime; download once via supplied loader; inspect data; freeze splits/scaler policy | Class-count plot, missingness/encoding checks, train/validation/test sizes and class support, working baseline setup |
| Week 2 | Train baseline; run six one-factor variants; run imbalance comparison; optional bonus only when core runs are complete | Real experiment ledger, saved checkpoints/histories, validation-only selection, best-run loss chart |
| Week 3 | Freeze final model; one final test; interpret errors; write report; build/rehearse slides; private evaluations | Final evaluated notebook, 3-5-page PDF, 8-12-slide deck, all four members ready for Q&A |

Teacher checkpoints explicitly ask to see class counts/split sizes in Week 1 and experiment log/loss chart in Week 2. Keep those readable and exportable early. [Brief p. 4]

## Proposed five-page report

The brief permits 3-5 pages. Five pages is a useful target for the required evidence without shrinking everything into unreadable tables. Confirm whether references count within the limit; until clarified, keep the whole document within five pages, including references and AI disclosure.

| Page | Main question | Evidence |
| --- | --- | --- |
| 1 | What is the problem and data? | Client framing, provenance/geography, 54 inputs/7 classes, class-count chart, key imbalance finding |
| 2 | How was the experiment made valid? | Split counts and seed, train-only preprocessing, class map, imbalance policy, baseline diagram/settings |
| 3 | What did the experiments show? | All required run rows, one changed factor each, selected-checkpoint metrics, learning curves, validation-only choice |
| 4 | How did the frozen model perform? | Comparable train/validation/test scores, per-class table, normalized confusion matrix, concise interpretation |
| 5 | Would we trust it? | Five wrong examples in compact form, cautious error hypotheses, deployment limits, next steps, references/disclosure |

Space is limited. Reuse one figure when it answers a clear question, use legible tables, and put fuller histories in the notebook. Do not replace explanation with screenshots of terminal output. Every figure needs a number, descriptive caption, axis labels, and the relevant split/run identity.

Draft conclusion structure, to fill only after measurement:

> On the declared held-out source-data split, the selected model achieved [measured results]. Performance was strongest for [observed classes] and weakest for [observed classes], with [actual support and errors]. We would consider it for [limited decision-support use justified by results], with human verification. The evaluation does not establish performance in a new region or a new collection period. The next validation needed before operational use is [specific evaluation].

The bracketed fields are a writing scaffold, not results. Do not convert them into confident claims without evidence. It is acceptable for the final answer to be “we would not yet trust this model for operational decisions.”

## Proposed ten-slide deck and speaking plan

Ten slides fits the required 8-12. The timing below totals ten minutes and follows the brief's six content blocks.

| Slide | Topic | Speaker role | Time |
| --- | --- | --- | ---: |
| 1 | Problem and limited client question | Data Lead | 1:00 |
| 2 | What a row and the feature groups mean | Data Lead | 1:00 |
| 3 | Class imbalance, preprocessing, and split | Data Lead | 1:00 |
| 4 | Baseline model and training choices | Model Lead | 1:15 |
| 5 | Early stopping and checkpoint selection | Model Lead | 0:45 |
| 6 | Controlled experiment matrix and actual results | Experiment Lead | 1:15 |
| 7 | Best-run loss curve and validation-only choice | Experiment Lead | 0:45 |
| 8 | Final test and per-class results | Report Lead | 1:00 |
| 9 | Five mistakes and what they suggest | Report Lead | 1:00 |
| 10 | Trust decision, scope limits, and next steps | Report Lead | 1:00 |

Each member speaks. Titles should state the point the slide proves once actual results exist. Preserve readable class names and values; avoid cramming the full 54-column dictionary onto a slide. Keep full run details and code in the notebook for the five-minute Q&A.

## Questions everyone should be able to answer

1. What is one observation, and where was the dataset collected?
2. Why are there 54 inputs but only ten columns to standardize?
3. Why shift labels from 1-7 to 0-6? Why sparse cross-entropy with softmax?
4. What was fit on training data only, and what exactly would leakage look like?
5. How does validation differ from testing? Why did the test set not choose the winner?
6. What does patience 2 mean, and which epoch's model was kept?
7. How did each experiment change only one factor relative to its reference?
8. Why might weighting improve rare-class recall and reduce overall accuracy?
9. What does macro-F1 measure? What is “accuracy for each class” here?
10. Why can training loss and validation loss differ even without overfitting?
11. What do the actual errors suggest, and which explanations are only hypotheses?
12. Why does a good random-split score not establish performance in Philippine forests?
13. Can you run and explain an assigned cell from a fresh kernel?
14. Which parts received AI assistance, and how did the group verify them?

Use the notebook's actual evidence to answer. Definitions alone will not explain a surprising run or class failure.

## Academic integrity and disclosure

The brief explicitly permits AI help for debugging and requires documenting its use; it also requires every member to understand every line. Research and planning assistance have occurred in this review. Before using AI more broadly to author assessed implementation or prose, clarify the instructor's policy beyond debugging. Do not claim the brief explicitly authorizes all forms of AI-generated submission content. [Brief p. 5]

Maintain a factual AI-use note: tool, purpose, affected sections, checks performed, and corrections made by members. A possible statement to adapt accurately is: “We used an AI assistant to review the assignment and locate official documentation. Group members checked the cited material and are responsible for the experiment design, executed results, and submitted explanations.” Add code/debugging/writing assistance if it actually occurs; never omit it to fit this example.

## Information still needed before execution

- Four member names, agreed leads, and availability.
- Actual submission date, submission platform, and accepted slide/peer-evaluation formats.
- The class MNIST and Audiobooks notebooks the brief says to start from.
- Group access to a compatible TensorFlow runtime and actual training-time budget.
- Teacher interpretation of winner metric, AI assistance beyond debugging, and final-test reproduction.

These do not invalidate the completed research. They determine implementation and submission details that the existing folder cannot establish.
