# Results and reporting guide - Group 8

Actual execution completed 2026-11-06T19:15:19+08:00. The numbers below come from the saved logs and final predictions. They replace planning assumptions with measured evidence. Your group will create its own PowerPoint.

## Main result

Validation selected **R1 (Width: 100-100)**. Its final test accuracy is **88.75%**, macro-F1 **0.8315**, and balanced accuracy **83.24%** on **58,102** test rows. The model made **6,534** errors.

The study used all 581,012 rows, with 464,809 training, 58,101 validation and 58,102 test rows. There were nine assessed runs and one separate two-epoch runtime pilot. The pilot did not evaluate the test set. The final assessment records **one model.evaluate call**; chart and class-metric checks use saved predictions.

## Experiment table to explain

| Run | One change from R0 | Epochs run / restored | Val. loss | Val. accuracy | Val. macro-F1 |
| --- | --- | --- | --- | --- | --- |
| R0 | Baseline | 16 / 14 | 0.3417 | 85.75% | 0.7827 |
| R1 | Width: 100-100 | 13 / 11 | 0.2793 | 88.66% | 0.8272 |
| R2 | Depth: 50-50-50 | 20 / 18 | 0.2889 | 88.38% | 0.8163 |
| R3 | Activation: tanh | 34 / 32 | 0.2682 | 89.31% | 0.8254 |
| R4 | Batch size: 500 | 22 / 20 | 0.3611 | 85.26% | 0.7628 |
| R5 | Learning rate: 0.0003 | 42 / 40 | 0.3433 | 85.87% | 0.7753 |
| R6 | Patience: 5 | 50 / 46 | 0.2901 | 88.21% | 0.8270 |
| R7 | Balanced training weights | 15 / 13 | 0.4965 | 79.59% | 0.7353 |
| R8 | Dropout: 0.2 | 24 / 22 | 0.4185 | 82.51% | 0.7114 |

R0-R6 cover the required baseline plus six one-factor changes. R7 adds a class-weight comparison; R8 adds dropout. Every variant compares to R0. We did not accumulate changes from row to row.

The rule was fixed before assessed training: highest validation macro-F1, then validation accuracy, lower validation loss, fewer parameters and run ID. Early stopping chooses the checkpoint within each run using validation loss. The table records metrics from that restored checkpoint.

The selected configuration is `{"activation": "relu", "batch_size": 100, "class_weight": false, "dropout": 0.0, "learning_rate": 0.001, "patience": 2, "units": [100, 100]}` with **16,307** parameters. It ran 13 epochs and restored epoch 11. A close single-seed difference does not prove one configuration is universally better.

## Results to show together

| Partition | Accuracy | Macro-F1 | Balanced accuracy |
| --- | --- | --- | --- |
| train | 89.29% | 0.8368 | 83.66% |
| validation | 88.66% | 0.8272 | 82.50% |
| test | 88.75% | 0.8315 | 83.24% |

These scores describe the same frozen checkpoint in inference mode. Training-history accuracy was accumulated while weights changed; do not substitute it into this comparison. The train-minus-validation accuracy gap is **0.64 percentage points**.

| True class | Test support | Precision | Recall | F1 |
| --- | --- | --- | --- | --- |
| Spruce/Fir | 21,184 | 90.78% | 85.99% | 0.8832 |
| Lodgepole Pine | 28,331 | 88.44% | 92.77% | 0.9056 |
| Ponderosa Pine | 3,576 | 85.89% | 88.84% | 0.8734 |
| Cottonwood/Willow | 274 | 73.10% | 91.24% | 0.8117 |
| Aspen | 949 | 73.27% | 67.86% | 0.7046 |
| Douglas-fir | 1,737 | 84.58% | 64.42% | 0.7314 |
| Krummholz | 2,051 | 90.59% | 91.57% | 0.9108 |

Say “recall for each class” when explaining the brief's “accuracy for each class.” A class's recall answers: of all cells truly in this class, what fraction did we label correctly? Precision answers: of cells predicted as this class, what fraction were right? Macro-F1 averages seven F1 scores equally. Balanced accuracy averages seven recalls.

## Two comparisons worth discussing

**Class weights:** R7 changed validation accuracy from 85.75% to 79.59%; macro-F1 changed from 0.7827 to 0.7353. Mean class recall changed from 75.15% to 87.35%. Explain the precision/recall and aggregate-accuracy trade-off. Do not claim that balancing helped every metric.

**Dropout:** R8 changed validation macro-F1 by -0.0713 relative to R0 and achieved 82.51% validation accuracy. Dropout removes hidden activations during training and is disabled at inference. Report the actual outcome even if it did not help. The teacher decides whether it qualifies as a technique beyond class coverage.

## Figures ready for your own slides

- [Class counts](../figures/Group8_Class_Counts.png): explain 85.22% in two dominant classes and 0.47% Cottonwood/Willow.
- [Validation comparison](../figures/Group8_Validation_Comparison.png): explain the fixed selection metric.
- [Selected-run loss curve](../figures/Group8_Best_Loss_Curve.png): explain early stopping, restored epoch and the curve shape.
- [Confusion matrices](../figures/Group8_Confusion_Matrices.png): rows are true labels; columns are predictions; the right diagonal gives recall.

The figures are grayscale and can be inserted into the group's presentation. Use the CSVs for editable tables instead of screenshots when possible.

## Five mistakes

Use [Group8_Five_Errors.csv](../artifacts/Group8_Five_Errors.csv). It contains original row IDs, true/predicted labels, original-unit features, wilderness and soil indicators. We selected the lowest-row-ID error from each available true class until five, then filled remaining slots by row ID. Do not describe these as a random sample of all errors.

Observed values establish what the model got wrong. Similar terrain, class overlap and minority representation are hypotheses about why; no causal attribution was computed. A high softmax score can be wrong. It is not a calibrated confidence guarantee.

## Defensible client answer

The measured score supports considering source-like records for supervised screening with human verification. The weakest class recall was **Douglas-fir (64.42%)**. That prevents treating the overall accuracy as a guarantee for each class.

This is a random split of four Colorado wilderness areas. We did not test a Philippine forest, an unseen region, managed forest, a later period, calibration, or repeated seeds. The task predicts cover type from land attributes; it does not forecast fires or detect deforestation. Before operational use, validate on the intended region and review class-specific costs of errors.

## Group review before submission

1. Add names and roles where your instructor requires them. No names or contribution claims were invented.
2. Read and explain the notebook, including the scaler, class-weight formula, selection rule and test guard. Every member should be able to explain a cell outside their lead role.
3. Read the five-page [PDF report](../output/pdf/Group8_Report.pdf), check its claims against the notebook, and follow the instructor's AI-use rules. The report discloses research, coding, execution, analysis and drafting assistance.
4. Build and rehearse your own 8-12-slide presentation. No PowerPoint was produced by this workflow.
5. Complete private peer evaluations using the teacher's form. A blank aid is in [templates](templates/Group8_Peer_Evaluation_Template.md); no scores were assigned.

## Quick Q&A answers

- **Why only ten scaled columns?** The other 44 already represent binary wilderness/soil membership.
- **Why labels 0-6?** Sparse categorical cross-entropy expects class indices corresponding to seven output positions.
- **Why use validation repeatedly but test once?** Validation selects settings and stopping points; the held-out test supplies a final assessment after selection.
- **Why did the highest accuracy not automatically win?** We declared macro-F1 first because the dataset is imbalanced; use the actual table to explain any difference.
- **Did weights or dropout help?** Quote their measured changes and the objective, not a general promise about either technique.
- **Can this identify Philippine trees?** This study provides no evidence for that target population.

## Evidence location

`artifacts/study_manifest.json` freezes data/split/source identities and settings. `artifacts/runs/` has each history, model and validation class report. `artifacts/selection.json` records the pre-test winner. `artifacts/final_test_metrics.json` and saved probabilities/predictions record the final assessment. `artifacts/verification.json` contains the evidence-check result once verification completes.
