# Group 8 Forest Cover Type: review and research

Initial review: 6 November 2026 (Asia/Manila). The first seven notes preserve that preparation and research snapshot. Use the [revised five-page report](../output/pdf/Group8_Academic_Report.pdf), [case study PowerPoint](../output/pptx/Group8_Case_Study.pptx), and [executed notebook](../Group8_Notebook.ipynb) for the current case study. See [12 Academic report and presentation design](12_academic_report_and_presentation_design.md) for the design sources and photograph credits.

## Main finding

The assignment is a supervised, seven-class **tabular deep learning** project. The strongest submission will combine a correct, reproducible notebook with controlled experiments, honest minority-class evaluation, and a clear explanation of where the model can be trusted. A complicated application is unnecessary for the stated deliverables.

The original [assignment brief](../Group8_Finals_Project.pdf) controls the requirements. All six pages were extracted and visually inspected, including the experiment table, deliverables, rubric, and final-page continuation. At the start of the review, it was the only file in the Reporting folder. There was no notebook, dataset, experiment output, report draft, presentation, or assigned member list to assess.

## Read in this order

| Document | What it answers |
| --- | --- |
| [01 Requirements and rubric](01_requirements-and-rubric.md) | Exactly what must be submitted, what earns points, and ambiguities in the brief |
| [02 Dataset research](02_dataset-research.md) | What the data represents, every feature group, class distribution, provenance, and limits |
| [03 Execution and experiment plan](03_execution-and-experiment-plan.md) | A proposed notebook structure, controlled runs, selection rule, and final-test protocol |
| [04 Training and evaluation research](04_training-and-evaluation-research.md) | Official API evidence, environment choices, reproducibility, weighting, and evaluation pitfalls |
| [05 Group and deliverables plan](05_group-and-deliverables-plan.md) | Work ownership, three-week checkpoints, report outline, slides, and Q&A preparation |
| [06 Working context](06_working-context.md) | Relevant lessons from the optional LLM_Vault scan and how to apply them here |
| [07 Sources and review limits](07_sources-and-review-limits.md) | Source register, evidence boundaries, and what remains unknown |
| [Experiment log](templates/experiment-log.csv) | Empty measurement fields for the planned runs; no fabricated results |
| [Final-test checklist](templates/final-test-checklist.md) | What to freeze before the single final evaluation |
| [Extracted assignment text](00_assignment-extracted.txt) | Searchable reference transcription; consult the PDF for original layout |

## Decisions proposed by this review

1. Keep the taught baseline: 54 inputs, two 50-unit ReLU layers, seven softmax outputs, Adam, sparse categorical cross-entropy, batch 100, early-stopping patience 2.
2. Make one fixed stratified train/validation/test split. Fit the scaler using training rows only; scale columns 0-9 and preserve columns 10-53 as binary indicators.
3. Run the baseline plus six separate one-factor changes. Add a class-weight comparison to investigate the central imbalance problem. A dropout comparison is an optional bonus experiment.
4. Choose the model using validation results only. Proposed primary criterion: macro-F1 because rare classes matter, while logging the required validation accuracy and loss for every run. Confirm any teacher-specific preference before experiments start.
5. Freeze the selected model and evaluate the test set once. Produce confusion matrices, per-class recall, and at least five errors from that frozen model, with no subsequent tuning.
6. Use the full dataset for the assessed experiment set if a training-only pilot shows acceptable runtime. If a 100,000-row sample is needed, freeze a representative stratified sample first and use it consistently for every assessed run.
7. Build one understandable notebook and export its evidence into the report and slides. Every member must code and explain the entire workflow.

These are recommendations, not decisions already agreed by the group or results already obtained.

## Findings that change the final story

- The source data describes 30 x 30 metre cells in four Colorado wilderness areas. It is not Philippine forest data or an image-classification dataset. [UCI dataset](https://archive.ics.uci.edu/dataset/31/covertype)
- The original class counts imply that Spruce/Fir and Lodgepole Pine together account for **85.22%** of rows; Cottonwood/Willow accounts for **0.47%**. Overall accuracy alone can conceal poor minority-class performance. Counts and calculations are in [02](02_dataset-research.md).
- Reducing every class to the smallest class would retain only 19,229 of 581,012 rows, discarding **96.69%** of the dataset. A training-only class-weight comparison is a better first investigation than that extreme undersampling policy.
- The brief requests at least six experiments but its table has seven rows including the baseline. Baseline plus six changes satisfies the stronger interpretation.
- No model accuracy, winning architecture, training time, or bonus improvement can honestly be reported yet.

## Next work after the initial review

The data, experiments and report have now been produced by the AI-assisted workflow. The group still needs to review and understand the work, add member names/roles, confirm the submission details, create its PowerPoint and complete private peer evaluations. The original class notebooks were not supplied; the implementation follows the baseline stated in the assignment brief.
