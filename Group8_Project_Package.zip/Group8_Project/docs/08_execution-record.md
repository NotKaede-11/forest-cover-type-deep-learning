# Execution record - Group 8

Started 6 November 2026 (Asia/Manila). This records implementation after the initial research pack. The user authorized the notebook, experiments, analysis, and PDF; the group will make its own PowerPoint. The PDF will use a simple grayscale layout and Stop Slop editing.

## Before the assessed experiments

- Located the existing Anaconda `py3-TF2` environment with TensorFlow 2.21.0 and Python 3.12.16. Native Windows exposes CPU training here.
- Created a project-local `.venv` with access to those existing packages. Added missing pandas, scikit-learn, nbformat, and nbclient to the project environment; did not replace the base environment's packages.
- Loaded the public dataset with `fetch_covtype`, caching inside the project `data` directory.
- Ran a separate two-epoch full-data runtime pilot. Epochs took 3.08 and 2.05 seconds; no test evaluation occurred. The pilot is excluded from the assessed experiment family.
- Selected the full dataset for all assessed runs. Training has 464,809 rows, validation 58,101, and test 58,102, stratified with fixed seeds 42 and 43.
- Fixed nine runs before assessed training: R0 baseline, R1 width, R2 depth, R3 activation, R4 batch size, R5 learning rate, R6 patience, R7 training-only balanced weights, R8 dropout. Each variant compares with R0 and changes one factor.
- Fixed a 50-epoch cap, fresh model/optimizer/callback state, deterministic operations, two intra-op threads, one inter-op thread, and `steps_per_execution=32` across runs.
- Fixed selection by highest validation macro-F1, then validation accuracy, lower loss, fewer parameters, and run ID. Each run restores its minimum-validation-loss checkpoint.
- Planned one final `model.evaluate` call plus saved-prediction analysis. Normal notebook reruns will load the saved final assessment.

## Actual evidence locations

The executable notebook source is `Group8_Study.py`; all training code appears inside `Group8_Notebook.ipynb` after building. `artifacts/study_manifest.json` identifies source, data, split, configuration, and environment. Each run writes its model, history, validation class report, and metrics. The selected model, final metrics, and prediction files are saved separately.

The completed-run outcome appears below. Member names, role assignments, private peer ratings, and actual human contribution claims remain for the group.

## Completed assessed study

All nine runs completed. Validation selected R1; final test accuracy 88.75%, macro-F1 0.8315, balanced accuracy 83.24%. The final test phase finished 2026-11-06T19:15:19+08:00 and records one evaluate call. The exact logs, errors and interpretation are in `09_results-and-reporting-guide.md`. Training was performed by the AI-assisted workflow, with member review and private evaluations left to the group.

## Verification and handoff

- The main notebook executed all ten code cells in order without cell errors. Saved evidence checks verified nine controlled configurations, checkpoint epochs, model hashes, split identities, validation-only selection and final metrics recomputed from predictions.
- A fresh-kernel reproduction loaded all nine verified saved runs and the saved final assessment. It performed no new training or test evaluation. See `artifacts/rerun_verification.json`.
- The final report is five pages. All five rendered pages were visually inspected; pixel checks confirmed grayscale output, text stayed within margins, and a Stop Slop phrase check passed. These checks do not establish PDF/UA tagging. See `artifacts/pdf_verification.json`.
- The group receives the notebook, report, model, raw logs, editable CSV tables, grayscale figures, source scripts, pinned requirements and cached public data. The portable ZIP excludes machine-specific Python/Jupyter environments.
- No PowerPoint, member contribution claim or filled private peer evaluation was created.
