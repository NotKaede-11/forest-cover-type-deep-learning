# Sources, evidence status, and review limits

Review/research date: 6 November 2026, Asia/Manila. This note describes the initial review snapshot; later implementation/results are recorded in [08](08_execution-record.md) and [09](09_results-and-reporting-guide.md). External pages were consulted using BrowserOS Neo. Library facts in the training research were checked against the official documentation by the research subtask; dataset and assignment analysis were checked in the main review.

## Evidence labels used in this pack

| Label | Meaning | Example |
| --- | --- | --- |
| Assignment requirement | Stated in the local PDF | 3-5-page report, dense-network baseline, final test once |
| Published source fact | Reported by the dataset owner or library documentation | Published class counts; scaler fit behavior |
| Calculated implication | Arithmetic from stated inputs, checked locally | 85.22% top-two share; 5,657 model parameters |
| Project choice | Recommended procedure that has not been executed or agreed | Macro-F1-first selection, 50-epoch cap, extra class-weight experiment |
| Inference/limitation | Reasoned interpretation, not a measured outcome | New-region performance requires separate validation |
| Measured project result | Requires actual execution evidence | None exists yet |

## Local materials and coverage

The initial Reporting folder contained only [Group8_Finals_Project.pdf](../Group8_Finals_Project.pdf), 76,083 bytes, six pages. All six pages were extracted and rendered; their complete page images were inspected. The final page is a single continuation bullet about early downloading. [00_assignment-extracted.txt](00_assignment-extracted.txt) is a search aid, not a substitute for table layout or the original brief.

Reviewed source SHA-256: `FF3FB121FAF3C74CE9FB649BF518D970DB40AB4B68C5EA69AD7823E57C779FB6`. This identifies the reviewed brief if another version is supplied later. Temporary page renders were removed after inspection; the original PDF was retained.

The optional LLM_Vault scan was bounded to personal workflow context as documented in [06](06_working-context.md). Its project claims were not independently revalidated, and no portfolio metrics are used as evidence for this assignment.

Codebase Memory was checked under Tier 2 verification. The Reporting project was indexed at generation `2026-11-06T05:02:27Z`; the graph returned only Project/Branch nodes. Coverage explicitly excluded the PDF by suffix and `docs`/`tmp` subtrees. The root-scope coverage result had three entries and no further page. Therefore this review relies on direct PDF/text inspection and filesystem inventory, not graph completeness or inferred code structure. There was no implementation code in the initial source inventory to trace.

## Dataset and evaluation sources

| Primary source | Claims supported | Used in |
| --- | --- | --- |
| [UCI Covertype](https://archive.ics.uci.edu/dataset/31/covertype) | Dataset size, geography, target, provenance, missingness, license, citation | 02, README |
| [Original covtype.info](https://archive.ics.uci.edu/ml/machine-learning-databases/covtype/covtype.info) | Feature order/units, all wilderness and soil codes, class map/counts, historical split/results | 02 |
| [scikit-learn dataset guide](https://scikit-learn.org/stable/datasets/real_world.html#forest-covertypes) | 30 x 30 metre patches, seven-class tabular task, loader behavior | Dataset verification |
| [fetch_covtype](https://scikit-learn.org/stable/modules/generated/sklearn.datasets.fetch_covtype.html) | Return shape, labels 1-7, feature names, caching, default no shuffle | 02 |
| [Grouped cross-validation](https://scikit-learn.org/stable/modules/cross_validation.html#cross-validation-iterators-for-grouped-data) | Why dependent groups need separation to assess unseen-group generalization | 02 |
| [train_test_split](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.train_test_split.html) | Stratification and reproducible split settings | 04 |
| [StandardScaler](https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.StandardScaler.html) | Training-fit statistics and transform behavior | 04 |
| [Common pitfalls: leakage](https://scikit-learn.org/stable/common_pitfalls.html#data-leakage) | Separation of training and held-out preprocessing/selection | 04 |
| [compute_class_weight](https://scikit-learn.org/stable/modules/generated/sklearn.utils.class_weight.compute_class_weight.html) | Balanced-weight formula | 04 |
| [Model evaluation](https://scikit-learn.org/stable/modules/model_evaluation.html#balanced-accuracy-score) | Balanced accuracy definition | 04 |
| [classification_report](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.classification_report.html) | Class metrics, support, macro vs weighted averages | 04 |
| [confusion_matrix](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.confusion_matrix.html) | Matrix axes and normalization | 04 |

## TensorFlow/Keras sources

| Primary source | Claims supported |
| --- | --- |
| [TensorFlow pip installation](https://www.tensorflow.org/install/pip) | Windows CPU/GPU support and version-specific runtime compatibility; conflicting Python ranges are disclosed in 04 |
| [Keras training APIs](https://keras.io/api/models/model_training_apis/) | Explicit validation, class weights, metrics versus weighted metrics, evaluate/predict, History |
| [Sparse categorical cross-entropy](https://keras.io/api/losses/probabilistic_losses/#sparsecategoricalcrossentropy-class) | Integer labels and logits/probability contract |
| [Adam](https://keras.io/api/optimizers/adam/) | Learning-rate default and optimizer |
| [EarlyStopping](https://keras.io/api/callbacks/early_stopping/) | Monitor/patience and explicit best-weight restoration |
| [Operation determinism](https://www.tensorflow.org/api_docs/python/tf/config/experimental/enable_op_determinism) | Seeds, repeatability conditions, performance costs and limitations |
| [Dropout](https://keras.io/api/layers/regularization_layers/dropout/) | Training-only regularization behavior |
| [ReduceLROnPlateau](https://keras.io/api/callbacks/reduce_lr_on_plateau/) | Optional scheduled learning-rate reduction |

See [04](04_training-and-evaluation-research.md) for claims with citations in context. API docs can change; record exact installed versions when implementing. The notes do not promise that today's unpinned package combination will work on every group member's machine.

## What was not done during the initial review

- No dataset was downloaded or loaded for this project. Published counts were cross-checked against their primary source; actual loaded-data counts and quality still need verification.
- No environment installation, tiny-fit preflight, training, tuning, model selection, final test, or performance benchmarking was run.
- No report PDF, slide deck, assessed notebook, peer evaluation, or final measured result was produced. These files are the requested findings and preparation documentation.
- No member roles, teacher identity, calendar deadline, actual client, or permission for expanded AI use was inferred from unrelated material.
- No claim of exhaustive knowledge of all forestry literature or every possible model is made. Research is bounded to the actual assignment, its dataset, and the implementation/evaluation decisions needed next.

## Research stopping point

The evidence is sufficient to start a compliant baseline study after the missing group/instructor facts are settled. More general searching is unlikely to resolve the next uncertainties: they require real data checks, runtime measurement, controlled training, and instructor-specific answers. Additional model ideas should be justified by observed validation problems and kept outside the protected final test.
