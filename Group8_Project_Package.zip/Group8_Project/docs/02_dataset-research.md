# Forest Cover Type dataset research

Primary sources accessed through BrowserOS Neo on 6 November 2026: [UCI dataset record](https://archive.ics.uci.edu/dataset/31/covertype), [original covtype.info](https://archive.ics.uci.edu/ml/machine-learning-databases/covtype/covtype.info), and [scikit-learn loader reference](https://scikit-learn.org/stable/modules/generated/sklearn.datasets.fetch_covtype.html). This note preserves the initial published-metadata review. The later [executed study](09_results-and-reporting-guide.md) loaded the full dataset and verified the published counts and encoding.

## What one row means

One observation is a 30 x 30 metre land cell. The task predicts one of seven forest cover types from cartographic variables. Ground-truth cover labels came from the US Forest Service Region 2 Resource Information System; predictors came from USGS and USFS information. The study covers four wilderness areas of Roosevelt National Forest, northern Colorado, with relatively little human disturbance. No satellite-image inputs are included in these 54 features. [UCI](https://archive.ics.uci.edu/dataset/31/covertype)

There are 581,012 observations, 54 predictor columns, and one separate target. The original documentation describes 12 underlying measures: ten quantitative measures plus wilderness designation and soil designation. Expanding those last two categorical measures produces 4 + 40 binary columns, giving 54 inputs. The target is the 55th column in the raw source file, not an input. [Original metadata](https://archive.ics.uci.edu/ml/machine-learning-databases/covtype/covtype.info)

Client framing: “Estimate the dominant forest cover type of a land cell from recorded terrain, hydrology, access-distance, wilderness, and soil attributes.” This is a proposed use description; no actual client, deployment, or ecological benefit has been established.

## Data dictionary: all 54 predictors

The positions below are zero-based NumPy positions in the documented source order. Inspect `feature_names` at load time to verify the implementation follows it. [Original feature order](https://archive.ics.uci.edu/ml/machine-learning-databases/covtype/covtype.info), [loader feature_names](https://scikit-learn.org/stable/modules/generated/sklearn.datasets.fetch_covtype.html)

| Position | Feature | Meaning and unit | Preprocessing |
| --- | --- | --- | --- |
| 0 | Elevation | Height in metres | Training-fitted standardization |
| 1 | Aspect | Direction of slope, degrees azimuth | Standardize for taught baseline; circular encoding is a separate optional experiment |
| 2 | Slope | Inclination in degrees | Standardize |
| 3 | Horizontal_Distance_To_Hydrology | Horizontal distance to nearest surface-water feature, metres | Standardize |
| 4 | Vertical_Distance_To_Hydrology | Vertical distance to nearest surface-water feature, metres | Standardize; do not assume every value must be nonnegative |
| 5 | Horizontal_Distance_To_Roadways | Horizontal distance to nearest road, metres | Standardize |
| 6 | Hillshade_9am | Summer-solstice illumination/shading index at 9 a.m., 0-255 | Standardize |
| 7 | Hillshade_Noon | Same index at noon, 0-255 | Standardize |
| 8 | Hillshade_3pm | Same index at 3 p.m., 0-255 | Standardize |
| 9 | Horizontal_Distance_To_Fire_Points | Horizontal distance to nearest wildfire ignition point, metres | Standardize; this is not a future-fire risk score |
| 10-13 | Wilderness_Area indicators 1-4 | Four binary columns naming the wilderness area | Keep 0/1 |
| 14-53 | Soil_Type indicators 1-40 | Forty binary columns identifying the local ecological landtype unit | Keep 0/1 |

For wilderness indicator `j` (1-4), the zero-based position is `9+j`. The designations are: 1 Rawah, 2 Neota, 3 Comanche Peak, 4 Cache la Poudre. For soil indicator `k` (1-40), its position is `13+k`. A 1 marks membership in that designation; 0 marks absence. Soil codes are local categories, not ordered magnitudes. [Original codebook](https://archive.ics.uci.edu/ml/machine-learning-databases/covtype/covtype.info)

The following compact mapping makes every soil column identifiable. Detailed soil descriptions are available in the linked original codebook; the group does not need to read 40 soil definitions aloud.

| Soil indicator | USFS ecological landtype code | Soil indicator | USFS ecological landtype code |
| ---: | ---: | ---: | ---: |
| 1 | 2702 | 21 | 7103 |
| 2 | 2703 | 22 | 7201 |
| 3 | 2704 | 23 | 7202 |
| 4 | 2705 | 24 | 7700 |
| 5 | 2706 | 25 | 7701 |
| 6 | 2717 | 26 | 7702 |
| 7 | 3501 | 27 | 7709 |
| 8 | 3502 | 28 | 7710 |
| 9 | 4201 | 29 | 7745 |
| 10 | 4703 | 30 | 7746 |
| 11 | 4704 | 31 | 7755 |
| 12 | 4744 | 32 | 7756 |
| 13 | 4758 | 33 | 7757 |
| 14 | 5101 | 34 | 7790 |
| 15 | 5151 | 35 | 8703 |
| 16 | 6101 | 36 | 8707 |
| 17 | 6102 | 37 | 8708 |
| 18 | 6731 | 38 | 8771 |
| 19 | 7101 | 39 | 8772 |
| 20 | 7102 | 40 | 8776 |

Source: [covtype.info, Code Designations](https://archive.ics.uci.edu/ml/machine-learning-databases/covtype/covtype.info). No assumption that numerical proximity of these codes implies ecological similarity is needed by the baseline.

## Target labels and published class distribution

The source uses labels 1-7. Subtract one for sparse categorical cross-entropy, producing 0-6; keep the original-name mapping when displaying results. Do not use the generic loader's target-column name as if it were the list of seven species names. [Loader](https://scikit-learn.org/stable/modules/generated/sklearn.datasets.fetch_covtype.html), [original class definitions and counts](https://archive.ics.uci.edu/ml/machine-learning-databases/covtype/covtype.info)

| Original ID | Model ID | Cover type | Published rows | Share, calculated |
| ---: | ---: | --- | ---: | ---: |
| 1 | 0 | Spruce/Fir | 211,840 | 36.4605% |
| 2 | 1 | Lodgepole Pine | 283,301 | 48.7599% |
| 3 | 2 | Ponderosa Pine | 35,754 | 6.1537% |
| 4 | 3 | Cottonwood/Willow | 2,747 | 0.4728% |
| 5 | 4 | Aspen | 9,493 | 1.6339% |
| 6 | 5 | Douglas-fir | 17,367 | 2.9891% |
| 7 | 6 | Krummholz | 20,510 | 3.5300% |
| | | Total | 581,012 | 100%, before display rounding |

Calculated implications, using these published counts:

- Top two classes: `(211840 + 283301) / 581012 = 85.22%`.
- Largest-to-smallest ratio: `283301 / 2747 = 103.13`.
- Always predicting Lodgepole Pine gives 48.76% accuracy on the published full distribution. This is a reference calculation, not a measured test baseline; compute the actual test comparison only in the final evaluation.
- Keeping 2,747 rows per class would retain `7 * 2747 = 19,229` rows and discard 96.69%. For a real training split, calculate the corresponding training-only quantities rather than resampling the complete dataset.
- A representative 100,000-row sample would contain roughly 473 Cottonwood/Willow examples in total, and only about 47 in a 10% test split. These are expectations, not observed split counts. Minority metrics become less stable as support shrinks.

## Loading and data-quality checks

Follow the assignment's `sklearn.datasets.fetch_covtype` path. It downloads when needed, caches under `~/scikit_learn_data` by default, accepts an explicit `data_home`, returns 54-column data and labels 1-7, and defaults to `shuffle=False`. An explicit data directory can make group setup easier. Record it without assuming every member's Windows username matches this machine. [Loader API](https://scikit-learn.org/stable/modules/generated/sklearn.datasets.fetch_covtype.html)

UCI reports no missing values. Verify this on the actual loaded arrays rather than inserting imputation because the generic checklist mentions it. Also check shape, finite numeric values, label set, binary values in the final 44 columns, and one active wilderness/soil indicator per row. If a check fails, investigate the source/load process before silently “fixing” it. [UCI missingness and encoding](https://archive.ics.uci.edu/dataset/31/covertype)

Retain original row IDs before sampling/splitting. Verify split IDs are disjoint, class counts add up, and all seven classes occur in every partition. Check repeated feature vectors and any conflicting labels; identical features do not prove identical physical cells because the provided predictors are not unique coordinates. Document the chosen treatment before modeling. These are proposed quality controls, not anomalies already observed.

The feature matrix alone occupies approximately 119.7 MiB as float32 or 239.4 MiB as float64, calculated from `581012 * 54 * bytes_per_value`. Pandas frames, copies, split arrays, optimizer state, and TensorFlow add memory overhead. This estimate supports trying a full-data pilot; it does not establish training speed or total memory usage.

## Historical results and comparison limits

The original source describes a historical split with 11,340 training, 3,780 validation, and 565,892 test records. It reports about 70% neural-network accuracy under that study's protocol. The class assignment instead suggests a shuffled three-way split such as 80/10/10. Those are different experiments. Historical accuracy must not be presented as this group's result, a target the group has achieved, or a directly comparable baseline. [Original study summary](https://archive.ics.uci.edu/ml/machine-learning-databases/covtype/covtype.info)

## What a good score would and would not establish

**Supported evaluation question:** performance on held-out cells from the sampled source population under the declared splitting policy.

**Inference requiring additional evidence:** performance in a new forest, a different country, a later time period, managed forests, or a different data-collection process. The source covers particular wilderness areas and input conditions. A random split can place observations from the same area on both sides; it is not a test of completely unseen areas. If deployment to new areas becomes a real objective, investigate grouped/geographic validation as a separate study. The general need to separate dependent groups is explained by [scikit-learn's grouped-validation guide](https://scikit-learn.org/stable/modules/cross_validation.html#cross-validation-iterators-for-grouped-data). This review has not measured spatial dependence or established that adjacent cells cross the proposed split.

Further limits: predicting cover type is not a species inventory of every individual tree, a biodiversity assessment, a deforestation detector, a fire forecast, or a replacement for field verification. Those outputs have different targets and evidence requirements.

Dataset attribution: Blackard, J. (1998). *Covertype* [Dataset]. UCI Machine Learning Repository. [DOI: 10.24432/C50K5N](https://doi.org/10.24432/C50K5N). The current UCI page lists CC BY 4.0; retain attribution and provenance when sharing data-derived work. [UCI record](https://archive.ics.uci.edu/dataset/31/covertype)
