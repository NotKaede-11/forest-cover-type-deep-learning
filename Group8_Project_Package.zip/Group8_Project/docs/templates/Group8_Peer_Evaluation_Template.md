# Group 8 - private peer evaluation template

Use the teacher's official form if one is provided. Each member completes a separate private evaluation of the other three members. This blank template does not assign ratings or claim contributions.

Evaluator: ____________________    Date: ____________________

Rate each category from 1 (poor) to 5 (excellent), based on work you observed.

| Other member | Contribution | Reliability | Teamwork | Understanding of the whole project | Factual comments/examples |
| --- | --- | --- | --- | --- | --- |
| ____________________ | | | | | |
| ____________________ | | | | | |
| ____________________ | | | | | |

Submit privately through the teacher's required channel. Do not put completed evaluations in the group's shared report or submission archive unless the teacher directs you to.
