# Final-test checkpoint

Use immediately before the first final test. This is a blank checklist, not evidence that any item is complete. Reference: [execution plan](../03_execution-and-experiment-plan.md).

- [ ] Required experiments completed and ledger reconciled with saved histories.
- [ ] Failed/pilot/optional runs clearly labeled; no fabricated or missing result substituted.
- [ ] Selection rule declared before experiments and applied to validation only.
- [ ] Selected run, selected epoch, model artifact, and validation metrics identify the same checkpoint.
- [ ] Model/preprocessing/class map/split IDs frozen and saved.
- [ ] Feature order and labels 0-6 verified.
- [ ] Train-only scaler and weighting/resampling provenance verified.
- [ ] Test rows disjoint from training/validation; no test-based tuning or trial scoring.
- [ ] Environment versions, device, seed policy, data scope, and evaluation timestamp recorded.
- [ ] Comparable train/validation inference metrics collected from the frozen model.
- [ ] Report/figure code checked using validation or synthetic examples before test access.
- [ ] Test interpretation agreed: one evaluate call plus fixed-model prediction analysis.
- [ ] Notebook rerun/reproduction policy understood; final outputs will be preserved.

Record before evaluation:

| Field | Value to record |
| --- | --- |
| Finalization date/time/timezone | |
| Selected run and epoch | |
| Model path and identity/hash | |
| Preprocessing and class-map identity | |
| Split artifact identity and actual sizes | |
| Dataset scope and version/provenance | |
| Selection rule and validation evidence | |
| Exact runtime/package versions | |
| Reviewer/member responsible | |

After the single evaluation phase:

- [ ] Save loss/accuracy immediately.
- [ ] Save fixed-model predictions with row IDs and true/predicted labels.
- [ ] Derive all remaining class metrics, confusion matrices, and error examples from saved predictions.
- [ ] Discuss weaknesses honestly; do not restart model selection using test feedback.
- [ ] Update report, slides, references, and AI disclosure from actual evidence.
